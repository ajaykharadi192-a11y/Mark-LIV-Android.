package com.ajay.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.ajay.jarvis.ui.theme.ComposeEmptyActivityTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            ComposeEmptyActivityTheme {
                JarvisScreen()
            }
        }
    }
}

@Composable
fun JarvisScreen() {
    val context = LocalContext.current

    var heardText by remember { mutableStateOf("अभी आपकी आवाज़ का इंतज़ार है।") }
    var replyText by remember {
        mutableStateOf("नमस्ते Ajju Boss! मैं MARK हूँ। बोलने के लिए माइक दबाएँ।")
    }
    var listening by remember { mutableStateOf(false) }
    var ttsReady by remember { mutableStateOf(false) }

    val tts = remember {
        lateinit var engine: TextToSpeech
        engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engine.language = Locale("hi", "IN")
                ttsReady = true
            }
        }
        engine
    }

    val recognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            SpeechRecognizer.createSpeechRecognizer(context)
        } else null
    }

    DisposableEffect(Unit) {
        onDispose {
            recognizer?.destroy()
            tts.stop()
            tts.shutdown()
        }
    }

    val handleCommand: (String) -> Unit = { command ->
        heardText = command
        listening = false
        val words = command.lowercase(Locale.ROOT)
        val prefs = context.getSharedPreferences("mark_memory", android.content.Context.MODE_PRIVATE)

        fun openUrl(url: String) {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        fun openSettings(action: String = Settings.ACTION_SETTINGS) {
            context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        fun launchSafely(intent: Intent) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }

        val answer = try {
            when {
                words.contains("hey jarvis") || words.contains("हे जार्विस") || words.contains("जार्विस") || words.contains("jarvis") || words.contains("hello") || words.contains("हेलो") || words.contains("नमस्ते") ->
                    "हाँ Ajju Bhai, बताइए! मैं सुन रहा हूँ।"

                words.contains("चुप") || words.contains("बंद हो जाओ") || words.contains("stop speaking") -> {
                    tts.stop(); "ठीक है Ajju Bhai, मैं चुप हो जाता हूँ।"
                }
                words.contains("हिंदी") -> "ठीक है Ajju Bhai, मैं हिंदी में बात करूँगा।"
                words.contains("समय") || words.contains("कितने बजे") || words.contains("time") -> {
                    val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
                    "Ajju Bhai, अभी समय $time है।"
                }
                words.contains("तारीख") || words.contains("date") -> {
                    val date = SimpleDateFormat("dd MMMM yyyy", Locale("hi", "IN")).format(Date())
                    "आज की तारीख $date है।"
                }
                words.contains("बैटरी") || words.contains("battery") -> {
                    val bm = context.getSystemService(android.content.Context.BATTERY_SERVICE) as android.os.BatteryManager
                    val level = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
                    "Ajju Bhai, फोन की बैटरी $level प्रतिशत है।"
                }
                words.contains("सेटिंग") || words.contains("settings") -> { openSettings(); "Ajju Bhai, फोन की Settings खोल रहा हूँ।" }
                words.contains("वाई-फाई") || words.contains("wifi") || words.contains("wi-fi") -> { openSettings(Settings.ACTION_WIFI_SETTINGS); "Wi-Fi Settings खोल रहा हूँ।" }
                words.contains("ब्लूटूथ") || words.contains("bluetooth") -> { openSettings(Settings.ACTION_BLUETOOTH_SETTINGS); "Bluetooth Settings खोल रहा हूँ।" }
                words.contains("ब्राइटनेस") || words.contains("brightness") || words.contains("डिस्प्ले") -> { openSettings(Settings.ACTION_DISPLAY_SETTINGS); "Display Settings खोल रहा हूँ, Ajju Bhai।" }
                words.contains("लॉक") || words.contains("lock screen") -> { openSettings(Settings.ACTION_SECURITY_SETTINGS); "स्क्रीन लॉक की सेटिंग खोल रहा हूँ। फोन लॉक करने के लिए सिस्टम अनुमति चाहिए।" }
                words.contains("फ्लैशलाइट") || words.contains("टॉर्च") || words.contains("torch") || words.contains("flashlight") -> { openSettings(Settings.ACTION_SETTINGS); "Ajju Bhai, Quick Settings नीचे खींचकर टॉर्च बटन दबाएँ। इस वर्ज़न में सीधे टॉर्च टॉगल उपलब्ध नहीं है।" }
                words.contains("वॉल्यूम बढ़") || words.contains("volume up") -> {
                    val am = context.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager
                    am.adjustVolume(android.media.AudioManager.ADJUST_RAISE, android.media.AudioManager.FLAG_SHOW_UI)
                    "वॉल्यूम बढ़ा दिया, Ajju Bhai।"
                }
                words.contains("वॉल्यूम कम") || words.contains("volume down") -> {
                    val am = context.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager
                    am.adjustVolume(android.media.AudioManager.ADJUST_LOWER, android.media.AudioManager.FLAG_SHOW_UI)
                    "वॉल्यूम कम कर दिया, Ajju Bhai।"
                }
                words.contains("youtube") || words.contains("यूट्यूब") -> {
                    val query = command.replace(Regex("(?i)youtube|यूट्यूब|पर|खोलो|चलाओ|खोजो|सर्च करो"), "").trim()
                    openUrl(if (query.isBlank()) "https://www.youtube.com" else "https://www.youtube.com/results?search_query=" + Uri.encode(query))
                    "Ajju Bhai, YouTube खोल रहा हूँ।"
                }
                words.contains("whatsapp") || words.contains("व्हाट्सएप") -> { launchSafely(context.packageManager.getLaunchIntentForPackage("com.whatsapp") ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"))); "WhatsApp खोल रहा हूँ।" }
                words.contains("कैमरा") || words.contains("camera") -> { launchSafely(Intent("android.media.action.IMAGE_CAPTURE")); "कैमरा खोल रहा हूँ।" }
                words.contains("कॉल") || words.contains("call") || words.contains("फोन लगाओ") -> { launchSafely(Intent(Intent.ACTION_DIAL)); "डायलर खोल रहा हूँ। नंबर चुनकर कॉल कर सकते हैं।" }
                words.contains("मैसेज") || words.contains("message") || words.contains("sms") -> { launchSafely(Intent(Intent.ACTION_VIEW, Uri.parse("smsto:" )).putExtra("sms_body", command)); "मैसेज लिखने की स्क्रीन खोल रहा हूँ। भेजने से पहले आप जाँच लें।" }
                words.contains("मौसम") || words.contains("weather") -> { openUrl("https://www.google.com/search?q=" + Uri.encode("आज का मौसम $command")); "मौसम की जानकारी खोज रहा हूँ।" }
                words.contains("खबर") || words.contains("news") -> { openUrl("https://news.google.com/"); "ताज़ा खबरें खोल रहा हूँ।" }
                words.contains("मैप") || words.contains("रास्ता") || words.contains("maps") || words.contains("दिशा") -> { openUrl("https://www.google.com/maps/search/" + Uri.encode(command)); "Maps खोल रहा हूँ।" }
                words.contains("इंटरनेट") || words.contains("सर्च") || words.contains("खोजो") || words.contains("search") || words.contains("जानकारी") -> { openUrl("https://www.google.com/search?q=" + Uri.encode(command)); "इंटरनेट पर खोज रहा हूँ।" }
                words.contains("टाइमर") || words.contains("timer") -> {
                    val minutes = Regex("(\\d+)").find(command)?.value?.toIntOrNull() ?: 1
                    launchSafely(Intent(android.provider.AlarmClock.ACTION_SET_TIMER).putExtra(android.provider.AlarmClock.EXTRA_LENGTH, (minutes * 60).coerceAtMost(86400)).putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, "JARVIS Timer").putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, false))
                    "$minutes मिनट का टाइमर सेट करने की स्क्रीन खोल रहा हूँ।"
                }
                words.contains("अलार्म") || words.contains("alarm") || words.contains("याद दिला") || words.contains("remind") -> { launchSafely(Intent(android.provider.AlarmClock.ACTION_SET_ALARM)); "अलार्म सेट करने की स्क्रीन खोल रहा हूँ।" }
                words.contains("नोट्स दिख") || words.contains("मेरी यादें") || words.contains("saved notes") -> {
                    val notes = prefs.getString("notes", "")?.trim().orEmpty()
                    if (notes.isBlank()) "अभी कोई नोट सेव नहीं है।" else "आपके सेव किए हुए नोट्स: $notes"
                }
                words.contains("नोट") || words.contains("याद रख") || words.contains("remember") || words.contains("save this") -> {
                    val note = command.replace(Regex("(?i)jarvis|hey|याद रखो|याद रखना|नोट बनाओ|नोट"), "").trim().ifBlank { command }
                    val old = prefs.getString("notes", "") ?: ""
                    prefs.edit().putString("notes", (old + "\n• " + note).trim()).apply()
                    "Ajju Bhai, मैंने यह नोट सेव कर लिया: $note"
                }
                words.contains("ईमेल") || words.contains("email") -> { launchSafely(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))); "ईमेल ऐप खोल रहा हूँ।" }
                words.contains("अनुवाद") || words.contains("translate") -> { openUrl("https://translate.google.com/?sl=auto&tl=hi&text=" + Uri.encode(command)); "अनुवाद खोल रहा हूँ।" }
                words.contains("फोटो") || words.contains("तस्वीर") || words.contains("image") -> { launchSafely(Intent(Intent.ACTION_GET_CONTENT).setType("image/*")); "तस्वीर चुनने की स्क्रीन खोल रहा हूँ। तस्वीर का विश्लेषण करने के लिए AI सेवा जोड़नी होगी।" }
                words.contains("गाना") || words.contains("म्यूजिक") || words.contains("music") || words.contains("वीडियो") -> { openUrl("https://www.youtube.com/results?search_query=" + Uri.encode(command)); "म्यूजिक या वीडियो खोज रहा हूँ।" }
                words.contains("स्टेटस") || words.contains("status") -> "Ajju Bhai, MARK चालू है। माइक से आवाज़ सुन सकता हूँ। Hey Jarvis की हमेशा चालू रहने वाली wake-word सुविधा अभी जोड़ी नहीं गई है।"
                words.contains("मेरे काम") || words.contains("कामों की सूची") || words.contains("task list") -> { val notes = prefs.getString("notes", "")?.trim().orEmpty(); if (notes.isBlank()) "आपकी सूची खाली है।" else "आपकी सेव की गई सूची: $notes" }
                words.contains("मज़ेदार") || words.contains("चुटकुला") || words.contains("joke") -> "Ajju Bhai, कंप्यूटर डॉक्टर के पास क्यों गया? क्योंकि उसे वायरस हो गया था!"
                words.contains("ऑफलाइन") || words.contains("offline") -> "फोन की इंटरनेट स्थिति Settings में जाँच सकते हैं। AI और वेब सर्च के लिए इंटरनेट चाहिए।"
                words.contains("मदद") || words.contains("commands") || words.contains("कमांड") -> "आप कह सकते हैं: Hey Jarvis, समय बताओ, तारीख बताओ, YouTube खोलो, WhatsApp खोलो, सेटिंग्स खोलो, वॉल्यूम बढ़ाओ, बैटरी बताओ, टाइमर लगाओ, नोट याद रखो, मौसम खोजो, Maps खोलो या इंटरनेट पर खोजो।"
                else -> { openUrl("https://www.google.com/search?q=" + Uri.encode(command)); "Ajju Bhai, इस कमांड के लिए वेब पर खोज रहा हूँ। पूरी AI बातचीत के लिए सुरक्षित Gemini API कनेक्शन जोड़ना बाकी है।" }
            }
        } catch (e: Exception) {
            "Ajju Bhai, यह काम अभी पूरा नहीं हो पाया। ऐप या अनुमति की जाँच करें।"
        }
        replyText = answer
        if (ttsReady) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "MARK_REPLY")
    }

    val startListening: () -> Unit = {
        if (recognizer == null) {
            replyText = "इस फोन पर Speech Recognition उपलब्ध नहीं है।"
        } else {
            try {
                val intent = Intent(
                    RecognizerIntent.ACTION_RECOGNIZE_SPEECH
                ).apply {
                    putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                    )
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                    putExtra(
                        RecognizerIntent.EXTRA_PROMPT,
                        "Ajju Boss, बोलिए..."
                    )
                }

                recognizer.setRecognitionListener(
                    object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            listening = true
                            replyText = "सुन रहा हूँ, Ajju Boss..."
                        }

                        override fun onBeginningOfSpeech() {
                            listening = true
                        }

                        override fun onResults(results: Bundle?) {
                            val spoken = results
                                ?.getStringArrayList(
                                    SpeechRecognizer.RESULTS_RECOGNITION
                                )
                                ?.firstOrNull()

                            if (spoken.isNullOrBlank()) {
                                listening = false
                                replyText = "आवाज़ समझ नहीं आई। फिर से बोलिए।"
                            } else {
                                handleCommand(spoken)
                            }
                        }

                        override fun onError(error: Int) {
                            listening = false
                            replyText = "आवाज़ नहीं समझ पाया। दोबारा माइक दबाएँ।"
                        }

                        override fun onRmsChanged(rmsdB: Float) {}
                        override fun onBufferReceived(buffer: ByteArray?) {}
                        override fun onEndOfSpeech() {
                            listening = false
                        }
                        override fun onPartialResults(partialResults: Bundle?) {}
                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    }
                )

                recognizer.startListening(intent)
            } catch (e: Exception) {
                listening = false
                replyText = "माइक शुरू नहीं हो पाया। दोबारा कोशिश करें।"
            }
        }
    }

    val microphonePermission =
        rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->
            if (granted) {
                startListening()
            } else {
                replyText = "आवाज़ सुनने के लिए Microphone permission चाहिए।"
            }
        }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFF030916)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0xFF071A35),
                            Color(0xFF030916),
                            Color(0xFF00040A)
                        )
                    )
                )
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(22.dp))

            Text(
                text = "M A R K",
                color = Color(0xFF65D9FF),
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 7.sp
            )

            Text(
                text = "PERSONAL AI ASSISTANT",
                color = Color(0xFF729DBD),
                fontSize = 11.sp,
                letterSpacing = 3.sp
            )

            Spacer(Modifier.height(38.dp))

            Box(
                modifier = Modifier
                    .size(190.dp)
                    .border(
                        width = 2.dp,
                        color = Color(0xFF28BFFF),
                        shape = CircleShape
                    )
                    .padding(12.dp)
                    .border(
                        width = 1.dp,
                        color = Color(0xFF176CBB),
                        shape = CircleShape
                    )
                    .background(
                        Brush.radialGradient(
                            listOf(
                                Color(0xFF174D83),
                                Color(0xFF092347),
                                Color(0xFF030916)
                            )
                        ),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (listening) "◉" else "✦",
                    color = Color(0xFF80E4FF),
                    fontSize = 66.sp
                )
            }

            Spacer(Modifier.height(20.dp))

            Text(
                text = if (listening) "LISTENING..." else "SYSTEM ONLINE",
                color = if (listening) Color(0xFF75F7D5)
                else Color(0xFF42C8FF),
                fontSize = 13.sp,
                letterSpacing = 3.sp
            )

            Spacer(Modifier.height(28.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF0B1B30)
                ),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        text = "YOU SAID",
                        color = Color(0xFF55CFFF),
                        fontSize = 11.sp,
                        letterSpacing = 2.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = heardText,
                        color = Color.White,
                        fontSize = 15.sp
                    )

                    Spacer(Modifier.height(18.dp))

                    Text(
                        text = "MARK",
                        color = Color(0xFF55CFFF),
                        fontSize = 11.sp,
                        letterSpacing = 2.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = replyText,
                        color = Color(0xFFD5E8FF),
                        fontSize = 15.sp
                    )
                }
            }

            Spacer(Modifier.height(24.dp))

            Button(
                onClick = {
                    val granted = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.RECORD_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED

                    if (granted) {
                        startListening()
                    } else {
                        microphonePermission.launch(
                            Manifest.permission.RECORD_AUDIO
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF087DC1)
                )
            ) {
                Text(
                    text = if (listening) "सुन रहा हूँ..." else "🎙  TALK TO MARK",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            Spacer(Modifier.height(14.dp))

            Text(
                text = "Hindi Voice  •  Quick Commands  •  AI Ready",
                color = Color(0xFF6885A5),
                fontSize = 11.sp
            )

            Spacer(Modifier.weight(1f))

            Text(
                text = "YOUR ASSISTANT • YOUR CONTROL",
                color = Color(0xFF416786),
                fontSize = 10.sp,
                letterSpacing = 2.sp
            )
            Spacer(Modifier.height(12.dp))
        }
    }
}
