# JARVIS / MARK Android Assistant — All-in-one source ZIP

This archive contains the Android Studio/Gradle source project, the futuristic cyan-neon dashboard, Settings page, microphone speech recognition, Android Text-to-Speech, conversation history, local notes/lists, Gemini text and image requests, phone intents, and a GitHub Actions workflow to build a debug APK.

## Build from GitHub (without Android Code Studio)

1. Upload this ZIP to the **root** of your `Mark-LIV-Android` repository using a name matching `JARVIS-50-commands-*.zip` if your repository's current workflow searches for that pattern.
2. Keep the repository's `.github/workflows` folder. Do not delete the workflow.
3. Commit the ZIP, then open **Actions → Build MARK APK** and open the latest run.
4. If the run succeeds, open its **Artifacts** section and download `JARVIS-debug-apk`.
5. If it fails, open the failed build step and copy the **first Kotlin compiler error** (not only the final `BUILD FAILED` lines).

The included `.github/workflows/android-apk.yml` also builds this project directly when the project files are at the repository root and uploads `app/build/outputs/apk/debug/app-debug.apk` as `JARVIS-debug-apk`.

## Gemini 404 handling

- The app calls the official Gemini API `v1beta/models` endpoint and checks which models list `generateContent` as a supported method.
- It prioritizes the selected model if available, then stable Flash/Pro model IDs, then other listed candidates.
- A `404` response causes the app to try the next candidate rather than stopping at the first missing model.
- Settings includes **Auto (Recommended)**, **Gemini 2.5 Flash**, **Gemini 2.5 Pro**, and **Gemini 2.0 Flash**, plus a Validate Key action.
- If all models fail, verify that the key is a Google Gemini API key, the Gemini API is enabled/available for that key, key restrictions are correct, and the phone has internet. Model availability and quotas are controlled by Google; no app-side fallback can fix a disabled API, invalid key, or account restriction.

## Requested 50 command categories

The command router includes patterns for: (1) greeting, (2) status, (3) Hindi mode, (4) spoken replies, (5) stop speaking, (6) YouTube, (7) WhatsApp, (8) camera, (9) Settings, (10) security/lock settings, (11–12) flashlight on/off, (13–14) volume up/down, (15) battery level, (16) dialer/call preparation, (17) contact picker, (18) WhatsApp message draft, (19) SMS draft, (20) contact creation form, (21/43) weather search, (22) general questions through Gemini, (23) explanations through Gemini, (24) translation page, (25) email draft, (26) time, (27) date, (28) timer screen, (29) alarm/reminder screen, (30/36/37/48) local notes and memory commands, (31–32) song/video search, (33) next media track, (34) pause music, (35) joke, (38) shopping list, (39) task list, (40) conversation history, (41) web search, (42) news, (44) Maps directions, (45) connectivity settings, (46) image picker + Gemini image analysis, (47) AI + web search, (49) assistant/phone settings, and (50) assistant status.

These are command categories, not a claim that every feature has production-grade automation. Use the exact phrases shown in Settings/README or similar Hindi/English phrases.

## Important real-world limitations

- The microphone button starts Android `SpeechRecognizer` on demand. **Always-on background “Hey JARVIS” is not implemented.** The app cannot continuously listen after being closed in this build.
- The assistant is intended to speak naturally in Hindi/Hinglish and address the user as “Ajju Bhai”. Android's installed TTS voice does the speaking. Puck/Charon/Kore/Fenrir/Aoede/Leda/Orus/Zephyr are saved preferences only; this app does not stream Gemini Live voices.
- Phone calls, messages, emails, alarms, and timers open a dialer/app/system screen for review. The app does not silently place calls or send messages.
- It cannot bypass the phone's PIN, password, pattern, fingerprint, or face unlock. Lock/unlock controls open Android security settings where needed.
- Brightness and flashlight require permissions and device support. Opening other apps requires them to be installed.
- YouTube Data API search is used only if enabled and a key is configured; otherwise the app opens official YouTube search results.
- Local notes, tasks, shopping lists, settings, and history use local app storage/preferences. This build does not use Room Database, and its conversation history is limited to a local stored list.
- API keys stored on the phone are suitable only for personal testing. For a public release, move Gemini and YouTube requests to a secure backend and do not commit keys to source control.

## Build verification

This is a **source ZIP, not an APK**. The local build could not be verified in this environment because the Gradle distribution download failed due to unavailable network access. The GitHub Actions build is the required compile check. A successful APK build does not guarantee that every phone-specific permission, API key, quota, or external app will work on every device.
