package com.ajay.jarvis

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.view.KeyEvent
import android.util.Base64
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.media.AudioManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.ajay.jarvis.ui.theme.ComposeEmptyActivityTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF030811)
private val Panel = Color(0xFF091722)
private val Cyan = Color(0xFF20DDF4)
private val Violet = Color(0xFF8A5CFF)
private val Magenta = Color(0xFFFF4FCB)
private val Muted = Color(0xFF85A6B4)
private val WhiteText = Color(0xFFE3F8FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ComposeEmptyActivityTheme { MarkApp() } }
    }
}

@Composable
private fun MarkApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("mark_settings", Context.MODE_PRIVATE) }
    var screen by remember { mutableStateOf("home") }
    var assistantName by remember { mutableStateOf(prefs.getString("assistant_name", "JARVIS") ?: "JARVIS") }
    var userName by remember { mutableStateOf(prefs.getString("user_name", "Ajju Bhai") ?: "Ajju Bhai") }
    var language by remember { mutableStateOf(prefs.getString("language", "Hindi + Hinglish") ?: "Hindi + Hinglish") }
    var geminiKey by remember { mutableStateOf(prefs.getString("gemini_key", "") ?: "") }
    var youtubeKey by remember { mutableStateOf(prefs.getString("youtube_key", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "Gemini 2.5 Flash") ?: "Gemini 2.5 Flash") }
    var personality by remember { mutableStateOf(prefs.getString("personality", "Assistant Mode") ?: "Assistant Mode") }
    var customPersonality by remember { mutableStateOf(prefs.getString("custom_personality", "Talk like a kind, witty, loyal friend. Keep replies useful and natural.") ?: "Talk like a kind, witty, loyal friend. Keep replies useful and natural.") }
    var voice by remember { mutableStateOf(prefs.getString("voice", "Puck") ?: "Puck") }
    var youtubeEnabled by remember { mutableStateOf(prefs.getBoolean("youtube_enabled", true)) }
    var showGemini by remember { mutableStateOf(false) }
    var showYoutube by remember { mutableStateOf(false) }
    var geminiStatus by remember { mutableStateOf(if (geminiKey.isNotBlank()) "Key Configured • Not validated" else "Not configured") }
    var youtubeStatus by remember { mutableStateOf("Unverified") }
    var listening by remember { mutableStateOf(false) }
    var heardText by remember { mutableStateOf("अभी आपकी आवाज़ का इंतज़ार है।") }
    var replyText by remember { mutableStateOf("नमस्ते $userName! बोलने के लिए माइक दबाएँ।") }
    var memoryText by remember { mutableStateOf("") }
    var validationBusy by remember { mutableStateOf(false) }
    var visionBusy by remember { mutableStateOf(false) }
    val history = remember {
        mutableStateListOf<String>().apply {
            try {
                val stored = JSONArray(prefs.getString("history_json", "[]") ?: "[]")
                for (i in 0 until stored.length()) add(stored.optString(i))
            } catch (_: Exception) { }
        }
    }
    var historyQuery by remember { mutableStateOf("") }
    fun persistHistory() {
        val arr = JSONArray()
        history.takeLast(100).forEach { arr.put(it) }
        prefs.edit().putString("history_json", arr.toString()).apply()
    }
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    var ttsReady by remember { mutableStateOf(false) }
    val tts = remember {
        lateinit var engine: TextToSpeech
        engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engine.language = if (language.startsWith("English")) Locale.US else Locale("hi", "IN")
                ttsReady = true
            }
        }
        engine
    }
    val recognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(context)) SpeechRecognizer.createSpeechRecognizer(context) else null
    }
    DisposableEffect(Unit) {
        onDispose { recognizer?.destroy(); tts.stop(); tts.shutdown() }
    }

    fun speak(text: String) { if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "MARK_REPLY") }
    fun openUrl(url: String) { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun openSettings(action: String = Settings.ACTION_SETTINGS) { context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun launchSafely(intent: Intent) { intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(intent) }
    fun launchApp(packageName: String, label: String) {
        val launch = context.packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) launchSafely(launch) else openUrl("https://www.google.com/search?q=" + Uri.encode("$label app"))
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) { replyText = "कोई तस्वीर नहीं चुनी गई।" }
        else if (geminiKey.isBlank()) { replyText = "तस्वीर का AI विश्लेषण करने के लिए Settings में Gemini API key जोड़ें।" }
        else scope.launch {
            visionBusy = true; replyText = "तस्वीर देख रहा हूँ…"
            val result = withContext(Dispatchers.IO) {
                try {
                    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    if (bytes == null) "तस्वीर पढ़ नहीं पाया। दूसरी तस्वीर चुनें।" else askGeminiVision(geminiKey, model, userName, language, bytes, context.contentResolver.getType(uri) ?: "image/jpeg")
                } catch (_: Exception) { "तस्वीर का विश्लेषण नहीं हो पाया। दूसरी तस्वीर चुनें या इंटरनेट जाँचें।" }
            }
            visionBusy = false; replyText = result; speak(result)
            history.add("आप: इस तस्वीर में क्या है?\n$assistantName: $result"); persistHistory()
        }
    }

    val handleCommand: (String) -> Unit = commandHandler@{ originalCommand ->
        heardText = originalCommand
        listening = false
        val memoryPrefs = context.getSharedPreferences("mark_memory", Context.MODE_PRIVATE)
        val raw = originalCommand.trim()
        val wordsRaw = raw.lowercase(Locale.ROOT)
        // If the wake phrase and an action arrive in the same recognition result, keep the action.
        val command = raw.replace(Regex("(?i)^\\s*(hey\\s+jarvis|jarvis|हे\\s*जार्विस|जार्विस)[, ]*"), "").trim().ifBlank { raw }
        val words = command.lowercase(Locale.ROOT)
        val answer = try {
            when {
                words.contains("speak hindi") || words.contains("हिंदी में बोल") || words == "हिंदी बोलो" -> { language = "Hindi"; tts.language = Locale("hi", "IN"); "ठीक है $userName, अब मैं हिंदी में बात करूँगा।" }
                words.contains("speak english") || words.contains("अंग्रेज़ी में बोल") || words == "english bolo" -> { language = "English"; tts.language = Locale.US; "Sure $userName, I’ll speak in English now." }
                wordsRaw in listOf("hey jarvis", "jarvis", "हे जार्विस", "जार्विस", "hello", "hi", "नमस्ते") || words in listOf("hello", "hi", "नमस्ते") -> "हाँ $userName, बताइए! मैं आपका दोस्त हूँ—क्या मदद करूँ?"
                words.contains("stop speaking") || words.contains("बोलना बंद") || words == "चुप" -> { tts.stop(); "ठीक है $userName, मैं अभी चुप हो जाता हूँ।" }
                words.contains("time") || words.contains("समय") || words.contains("कितने बजे") -> "अभी ${SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())} बजे हैं।"
                words.contains("date") || words.contains("तारीख") || words.contains("आज कौन सा दिन") -> "आज ${SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("hi", "IN")).format(Date())} है।"
                words.contains("battery") || words.contains("बैटरी") || words.contains("चार्ज कितना") -> {
                    val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                    "फोन की बैटरी ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} प्रतिशत है।"
                }
                words.contains("status") || words.contains("स्टेटस") || words.contains("सुन रहे") -> "${assistantName} तैयार है, $userName। माइक दबाकर बोलिए। बैकग्राउंड wake-word सुनना अभी सक्रिय नहीं है।"
                words.contains("stop music") || words.contains("pause music") || words.contains("गाना बंद") || words.contains("म्यूजिक बंद") || words.contains("संगीत रोक") -> {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE))
                    "म्यूज़िक रोकने का अनुरोध भेज दिया। अगर ऐप अनुमति दे तो गाना रुक जाएगा।"
                }
                words.contains("next song") || words.contains("next track") || words.contains("अगला गाना") -> {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_NEXT)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_NEXT))
                    "अगले गाने का अनुरोध भेज दिया।"
                }
                words.contains("set volume") || words.contains("वॉल्यूम") && Regex("\\d{1,3}\\s*%?").containsMatchIn(words) -> {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val pct = Regex("(\\d{1,3})").find(words)?.value?.toIntOrNull()?.coerceIn(0, 100) ?: 50
                    val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, (max * pct / 100.0).toInt(), AudioManager.FLAG_SHOW_UI)
                    "मीडिया वॉल्यूम लगभग $pct प्रतिशत कर दिया।"
                }
                words.contains("volume up") || words.contains("वॉल्यूम बढ़") || words.contains("आवाज़ बढ़ाओ") -> { (context.getSystemService(Context.AUDIO_SERVICE) as AudioManager).adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); "वॉल्यूम बढ़ा दिया।" }
                words.contains("volume down") || words.contains("वॉल्यूम कम") || words.contains("आवाज़ कम") -> { (context.getSystemService(Context.AUDIO_SERVICE) as AudioManager).adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); "वॉल्यूम कम कर दिया।" }
                words.contains("brightness") || words.contains("ब्राइटनेस") || words.contains("रोशनी बढ़") || words.contains("डिस्प्ले") -> {
                    if (Settings.System.canWrite(context)) {
                        val pct = Regex("(\\d{1,3})").find(words)?.value?.toIntOrNull()?.coerceIn(1, 100) ?: if (words.contains("कम") || words.contains("down")) 30 else 70
                        Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, pct * 255 / 100)
                        "ब्राइटनेस लगभग $pct प्रतिशत कर दी।"
                    } else { context.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + context.packageName))); "ब्राइटनेस बदलने के लिए अगली स्क्रीन पर अनुमति दें, फिर कमांड दोहराएँ।" }
                }
                words.contains("flashlight on") || words.contains("torch on") || words.contains("टॉर्च चालू") || words.contains("फ्लैशलाइट चालू") -> {
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                        if (id != null) { cm.setTorchMode(id, true); "टॉर्च चालू कर दी।" } else "इस फोन में फ्लैशलाइट उपलब्ध नहीं है।"
                    } else "टॉर्च के लिए Settings में Camera permission दें।"
                }
                words.contains("flashlight off") || words.contains("torch off") || words.contains("टॉर्च बंद") || words.contains("फ्लैशलाइट बंद") -> {
                    val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                    val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                    if (id != null && ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) { cm.setTorchMode(id, false); "टॉर्च बंद कर दी।" } else "टॉर्च बंद करने के लिए Camera permission जाँचें।"
                }
                words.contains("wifi") || words.contains("वाई-फाई") -> { openSettings(Settings.ACTION_WIFI_SETTINGS); "Wi-Fi सेटिंग्स खोल रहा हूँ।" }
                words.contains("bluetooth") || words.contains("ब्लूटूथ") -> { openSettings(Settings.ACTION_BLUETOOTH_SETTINGS); "Bluetooth सेटिंग्स खोल रहा हूँ।" }
                words.contains("internet settings") || words.contains("network settings") || words.contains("नेटवर्क सेटिंग") || words.contains("connectivity") -> { openSettings(Settings.ACTION_WIRELESS_SETTINGS); "नेटवर्क सेटिंग्स खोल रहा हूँ।" }
                words.contains("lock screen") || words.contains("screen lock") || words.contains("लॉक सेटिंग") || words.contains("unlock phone") || words.contains("फोन अनलॉक") || words == "lock phone" -> { openSettings(Settings.ACTION_SECURITY_SETTINGS); "सिक्योरिटी सेटिंग्स खोल रहा हूँ। मैं PIN या बायोमेट्रिक को bypass नहीं कर सकता।" }
                words.contains("open settings") || words == "settings" || words.contains("फोन सेटिंग") || words.contains("सेटिंग खोल") -> { openSettings(); "फोन की Settings खोल रहा हूँ।" }
                words.contains("open youtube") || words == "youtube" || words.contains("यूट्यूब खोल") -> { launchSafely(context.packageManager.getLaunchIntentForPackage("com.google.android.youtube") ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))); "YouTube खोल रहा हूँ।" }
                words.contains("whatsapp message") || words.contains("send whatsapp") || words.contains("व्हाट्सएप मैसेज") || words.contains("व्हाट्सएप पर") -> {
                    val message = Regex("(?i)send whatsapp to (.+?) saying (.+)").find(command)?.groupValues?.get(2)?.trim() ?: command.replace(Regex("(?i)hey jarvis|jarvis|send whatsapp|whatsapp message|व्हाट्सएप मैसेज|व्हाट्सएप पर|को भेजो|को बोलो|कहना"), "").trim()
                    val intent = Intent(Intent.ACTION_SEND).setType("text/plain").setPackage("com.whatsapp").putExtra(Intent.EXTRA_TEXT, message.ifBlank { "" })
                    try { launchSafely(intent); "WhatsApp खुल रहा है। भेजने से पहले चैट और मैसेज खुद जाँचकर Send दबाएँ।" } catch (_: Exception) { launchApp("com.whatsapp", "WhatsApp"); "WhatsApp खुल रहा है। मैसेज भेजने से पहले जाँच लें।" }
                }
                words.contains("whatsapp") || words.contains("व्हाट्सएप") -> { launchApp("com.whatsapp", "WhatsApp"); "WhatsApp खोल रहा हूँ।" }
                words.contains("instagram") || words.contains("इंस्टाग्राम") -> { launchApp("com.instagram.android", "Instagram"); "Instagram खोल रहा हूँ।" }
                words.contains("spotify") || words.contains("स्पॉटिफाई") -> { launchApp("com.spotify.music", "Spotify"); "Spotify खोल रहा हूँ।" }
                words.contains("open camera") || words == "camera" || words.contains("कैमरा खोल") -> { launchSafely(Intent("android.media.action.IMAGE_CAPTURE")); "कैमरा खोल रहा हूँ।" }
                words.contains("save contact") || words.contains("contact save") || words.contains("नंबर सेव") || words.contains("कॉन्टैक्ट सेव") -> {
                    val name = command.replace(Regex("(?i)save contact|contact save|नंबर सेव करो|कॉन्टैक्ट सेव करो|सेव कॉन्टैक्ट"), "").trim().ifBlank { "New contact" }
                    launchSafely(Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI).putExtra(ContactsContract.Intents.Insert.NAME, name))
                    "नया कॉन्टैक्ट फॉर्म खोल रहा हूँ। नंबर भरकर Save दबाएँ।"
                }
                words.contains("contacts") || words.contains("find contact") || words.contains("contact खोज") || words.contains("कॉन्टैक्ट") -> { launchSafely(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)); "कॉन्टैक्ट चुनने की स्क्रीन खोल रहा हूँ।" }
                words.contains("call ") || words.startsWith("call") || words.contains("कॉल") || words.contains("फोन लगाओ") -> {
                    val number = Regex("[+]?\\d[\\d -]{5,}").find(command)?.value?.replace(" ", "")
                    if (!number.isNullOrBlank()) launchSafely(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))) else launchSafely(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI))
                    "डायलर या कॉन्टैक्ट चयन खोल दिया। कॉल करने से पहले नंबर जाँचें और खुद Call दबाएँ।"
                }
                words.contains("sms") || words.contains("text message") || words.contains("एसएमएस") || words.contains("मैसेज लिख") -> {
                    val body = command.replace(Regex("(?i)send sms|sms|text message|एसएमएस|मैसेज लिखो|मैसेज भेजो"), "").trim()
                    launchSafely(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")).putExtra("sms_body", body))
                    "SMS ड्राफ्ट खोल दिया। भेजने से पहले नंबर और मैसेज जाँचें।"
                }
                words.contains("email") || words.contains("ईमेल") -> {
                    val body = command.replace(Regex("(?i)email|ईमेल|लिखो|भेजो"), "").trim()
                    launchSafely(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).putExtra(Intent.EXTRA_TEXT, body))
                    "ईमेल ड्राफ्ट खोल रहा हूँ। भेजने से पहले जाँच लें।"
                }
                words.contains("weather") || words.contains("मौसम") -> { openUrl("https://www.google.com/search?q=" + Uri.encode("weather near me $command")); "आपके इलाके का मौसम खोज रहा हूँ।" }
                words.contains("news") || words.contains("खबर") || words.contains("समाचार") -> { openUrl("https://news.google.com/"); "ताज़ा खबरें खोल रहा हूँ।" }
                words.contains("maps") || words.contains("दिशा") || words.contains("रास्ता") || words.contains("मैप") -> { openUrl("https://www.google.com/maps/dir/?api=1&destination=" + Uri.encode(command.replace(Regex("(?i)open maps|maps|दिशा बताओ|रास्ता बताओ|मैप खोलो"), "").trim())); "Maps में रास्ता खोल रहा हूँ।" }
                words.contains("timer") || words.contains("टाइमर") -> {
                    val minutes = Regex("(\\d+)").find(command)?.value?.toIntOrNull()?.coerceIn(1, 1440) ?: 1
                    launchSafely(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, minutes * 60).putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS Timer").putExtra(AlarmClock.EXTRA_SKIP_UI, false))
                    "$minutes मिनट का टाइमर सेट करने की स्क्रीन खोल रहा हूँ। वहाँ पुष्टि करें।"
                }
                words.contains("show reminders") || words.contains("मेरे रिमाइंडर") || words.contains("रिमाइंडर दिख") -> { val reminders = memoryPrefs.getString("reminders", "") ?: ""; if (reminders.isBlank()) "अभी कोई रिमाइंडर नोट सेव नहीं है।" else "आपके रिमाइंडर नोट: $reminders" }
                words.contains("edit reminder") || words.contains("रिमाइंडर बदलो") || words.contains("रिमाइंडर एडिट") -> { val reminderText = command.replace(Regex("(?i)edit reminder|रिमाइंडर बदलो|रिमाइंडर एडिट"), "").trim(); if (reminderText.isNotBlank()) memoryPrefs.edit().putString("reminders", "• $reminderText").apply(); launchSafely(Intent(AlarmClock.ACTION_SET_ALARM)); "रिमाइंडर नोट अपडेट किया। Clock में समय चुनकर सेव करें।" }
                words.contains("delete reminder") || words.contains("रिमाइंडर हटाओ") || words.contains("रिमाइंडर मिटाओ") -> { memoryPrefs.edit().remove("reminders").apply(); "लोकल रिमाइंडर नोट साफ कर दिए। फोन के Clock ऐप में बने अलार्म अलग से हटाने होंगे।" }
                words.contains("alarm") || words.contains("अलार्म") || words.contains("remind") || words.contains("याद दिला") -> {
                    val reminderText = command.replace(Regex("(?i)hey jarvis|jarvis|remind me|remind|alarm|अलार्म|याद दिलाओ|याद दिला"), "").trim()
                    if (reminderText.isNotBlank()) { val old = memoryPrefs.getString("reminders", "") ?: ""; memoryPrefs.edit().putString("reminders", (old + "\n• " + reminderText).trim()).apply() }
                    launchSafely(Intent(AlarmClock.ACTION_SET_ALARM)); "रिमाइंडर का नोट सेव किया और Clock की अलार्म स्क्रीन खोल दी। सही समय चुनकर सेव करना पुष्टि करें।"
                }
                words.contains("shopping list") || words.contains("खरीदारी सूची") -> { val old = memoryPrefs.getString("shopping", "") ?: ""; val item = command.replace(Regex("(?i)shopping list|खरीदारी सूची|में जोड़ो|add"), "").trim(); memoryPrefs.edit().putString("shopping", (old + "\n• " + item).trim()).apply(); "खरीदारी सूची में सेव कर लिया।" }
                words.contains("task list") || words.contains("मेरे काम") || words.contains("टास्क दिख") -> { val tasks = memoryPrefs.getString("tasks", "") ?: ""; if (tasks.isBlank()) "अभी कोई टास्क सेव नहीं है।" else "आपकी टास्क सूची: $tasks" }
                words.contains("add task") || words.contains("टास्क जोड़") || words.contains("काम याद रख") -> { val old = memoryPrefs.getString("tasks", "") ?: ""; val task = command.replace(Regex("(?i)add task|टास्क जोड़ो|टास्क जोड़|काम याद रखो"), "").trim(); memoryPrefs.edit().putString("tasks", (old + "\n• " + task).trim()).apply(); "टास्क सेव कर लिया।" }
                words.contains("show shopping") || words.contains("खरीदारी दिख") -> { val list = memoryPrefs.getString("shopping", "") ?: ""; if (list.isBlank()) "खरीदारी सूची खाली है।" else "खरीदारी सूची: $list" }
                words.contains("saved notes") || words.contains("read notes") || words.contains("नोट्स दिख") || words.contains("मेरी यादें") || words.contains("क्या याद रखा") -> { val notes = memoryPrefs.getString("notes", "")?.trim().orEmpty(); if (notes.isBlank()) "अभी कोई नोट सेव नहीं है।" else "आपके नोट्स: $notes" }
                words.contains("forget all") || words.contains("clear memories") || words.contains("भूल जाओ") || words.contains("नोट मिटा") || words.contains("यादें साफ") -> { memoryPrefs.edit().remove("notes").remove("tasks").remove("shopping").apply(); "सेव किए हुए नोट, टास्क और खरीदारी सूची साफ कर दी।" }
                words.contains("remember") || words.contains("याद रख") || words.contains("save note") || words.contains("नोट सेव") || words.contains("नोट बनाओ") -> {
                    val note = command.replace(Regex("(?i)remember|save note|नोट सेव करो|नोट बनाओ|याद रखो|याद रखना|jarvis"), "").trim().ifBlank { command }
                    val old = memoryPrefs.getString("notes", "") ?: ""
                    memoryPrefs.edit().putString("notes", (old + "\n• " + note).trim()).apply()
                    "ठीक है $userName, मैंने यह नोट अपने फोन की लोकल मेमोरी में सेव कर लिया।"
                }
                words.contains("history") || words.contains("इतिहास") || words.contains("पुरानी बातचीत") -> { screen = "history"; "बातचीत का इतिहास खोल रहा हूँ।" }
                words.contains("vision") || words.contains("image") || words.contains("फोटो समझाओ") || words.contains("तस्वीर समझाओ") || words.contains("photo question") -> { imagePicker.launch("image/*"); "तस्वीर चुनने की स्क्रीन खोल रहा हूँ। चुनने के बाद Gemini उसका विश्लेषण करेगा।" }
                words.contains("translate") || words.contains("अनुवाद") || words.contains("मतलब बताओ") -> { openUrl("https://translate.google.com/?sl=auto&tl=hi&text=" + Uri.encode(command.replace(Regex("(?i)translate|अनुवाद करो|अनुवाद|मतलब बताओ"), "").trim())); "अनुवाद खोल रहा हूँ।" }
                words.contains("joke") || words.contains("चुटकुला") || words.contains("जोक") -> "एक बार कंप्यूटर डॉक्टर के पास गया। डॉक्टर ने पूछा—क्या परेशानी है? कंप्यूटर बोला—मुझे वायरस हो गया है! 😄"
                words.contains("sleep") || words.contains("सो जाओ") -> { screen = "sleep"; "ठीक है दोस्त, स्लीप स्क्रीन पर जा रहा हूँ। वापस आने के लिए Back दबाएँ।" }
                words.contains("open app") || words.startsWith("open ") || words.startsWith("खोलो ") || words.startsWith("खोल ") -> {
                    val appName = command.replace(Regex("(?i)^open app|^open|^खोलो|^खोल"), "").trim()
                    val apps = listOf("com.google.android.youtube" to "YouTube", "com.whatsapp" to "WhatsApp", "com.instagram.android" to "Instagram", "com.spotify.music" to "Spotify", "com.google.android.gm" to "Gmail", "com.google.android.apps.maps" to "Maps", "com.android.chrome" to "Chrome", "com.android.settings" to "Settings")
                    val match = apps.firstOrNull { it.second.equals(appName, true) || it.second.lowercase().contains(appName.lowercase()) }
                    if (match != null) { launchApp(match.first, match.second); "${match.second} खोल रहा हूँ।" } else { openUrl("https://www.google.com/search?q=" + Uri.encode("open $appName app android")); "यह ऐप फोन में नहीं मिला; वेब पर खोज रहा हूँ।" }
                }
                words.contains("google search") || words.contains("search web") || words.contains("इंटरनेट पर खोज") || words.contains("सर्च करो") -> { val q = command.replace(Regex("(?i)google search|search web|इंटरनेट पर खोजो|इंटरनेट पर खोज|सर्च करो"), "").trim(); openUrl("https://www.google.com/search?q=" + Uri.encode(q)); "इंटरनेट पर खोज रहा हूँ।" }
                words.contains("song") || words.contains("गाना खोज") || words.contains("search video") || words.contains("वीडियो खोज") || words.contains("youtube") || words.startsWith("play ") || words.contains("चलाओ") -> {
                    val q = command.replace(Regex("(?i)hey jarvis|jarvis|search song|song|search video|youtube|on youtube|play|वीडियो खोजो|वीडियो खोज|गाना खोजो|गाना खोज|खोजो|चलाओ|पर"), "").trim()
                    if (youtubeEnabled && youtubeKey.isNotBlank()) {
                        scope.launch { val videoUrl = withContext(Dispatchers.IO) { searchYoutube(youtubeKey, q) }; if (videoUrl != null) openUrl(videoUrl) else openUrl("https://www.youtube.com/results?search_query=" + Uri.encode(q)) }
                        "YouTube पर खोज रहा हूँ।"
                    } else { openUrl("https://www.youtube.com/results?search_query=" + Uri.encode(q)); "YouTube पर खोज रहा हूँ।" }
                }
                words.contains("command list") || words.contains("help") || words.contains("कमांड बताओ") || words.contains("क्या कर सकते") -> "मैं 50 तरह के कामों में मदद के लिए तैयार हूँ: 1 Hey Jarvis greeting, 2 status, 3 Hindi/English, 4 बोलकर जवाब, 5 चुप, 6 YouTube, 7 WhatsApp, 8 Camera, 9 Settings, 10 lock settings, 11 torch on, 12 torch off, 13 volume up, 14 volume down, 15 battery, 16 dialer/call draft, 17 contacts, 18 WhatsApp draft, 19 SMS draft, 20 save contact form, 21 weather, 22 general questions, 23 explain topic, 24 translate, 25 email draft, 26 time, 27 date, 28 timer, 29 alarm, 30 notes, 31 song search, 32 video search, 33 next track, 34 pause music, 35 joke, 36 remember, 37 read notes, 38 shopping list, 39 tasks, 40 history, 41 web search, 42 news, 43 local weather search, 44 Maps directions, 45 connectivity settings, 46 vision image picker, 47 AI + web search, 48 save note, 49 phone settings, 50 status. कुछ काम Android permission, ऐप या पुष्टि पर निर्भर हैं।"
                else -> {
                    val promptCommand = when {
                        words.startsWith("explain ") || words.startsWith("समझाओ ") -> "दोस्त की तरह आसान हिंदी/Hinglish में समझाओ: $command"
                        words.startsWith("translate to english ") -> "Translate to English: " + command.substringAfter("translate to english ")
                        words.startsWith("translate to hindi ") -> "Translate to Hindi: " + command.substringAfter("translate to hindi ")
                        words.startsWith("ai web search ") || words.startsWith("एआई खोज ") -> { openUrl("https://www.google.com/search?q=" + Uri.encode(command)); "मैं वेब खोज खोल रहा हूँ और AI जवाब भी तैयार कर रहा हूँ।\n" }
                        else -> command
                    }
                    if (geminiKey.isNotBlank()) {
                        scope.launch {
                            replyText = "सोच रहा हूँ, $userName…"
                            val recent = history.takeLast(8).joinToString("\n")
                            val aiAnswer = withContext(Dispatchers.IO) { askGemini(geminiKey, model, if (personality == "Custom") customPersonality else personality, assistantName, userName, language, if (recent.isBlank()) promptCommand else "Recent conversation:\n$recent\nUser: $promptCommand") }
                            replyText = aiAnswer; speak(aiAnswer)
                            if (history.isNotEmpty()) { history[history.lastIndex] = "आप: $originalCommand\n$assistantName: $aiAnswer"; persistHistory() }
                        }
                        "सोच रहा हूँ, $userName…"
                    } else {
                        openUrl("https://www.google.com/search?q=" + Uri.encode(command))
                        "इस सवाल के लिए Gemini API key Settings में जोड़ें। अभी वेब खोज खोल रहा हूँ।"
                    }
                }
            }
        } catch (_: Exception) { "यह काम पूरा नहीं हो पाया। अनुमति, इंटरनेट या ऐप की उपलब्धता जाँचें।" }
        replyText = answer
        history.add("आप: $originalCommand\n$assistantName: $answer")
        if (history.size > 100) while (history.size > 100) history.removeAt(0)
        persistHistory()
        speak(answer)
    }

    val startListening: () -> Unit = {
        if (recognizer == null) replyText = "इस फोन पर Speech Recognition उपलब्ध नहीं है।"
        else try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (language.startsWith("English")) "en-IN" else "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "$userName, बोलिए…")
            }
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { listening = true; replyText = "सुन रहा हूँ, $userName…" }
                override fun onBeginningOfSpeech() { listening = true }
                override fun onResults(results: Bundle?) { val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull(); if (spoken.isNullOrBlank()) { listening = false; replyText = "आवाज़ समझ नहीं आई। फिर बोलिए।" } else handleCommand(spoken) }
                override fun onError(error: Int) { listening = false; replyText = "आवाज़ नहीं समझ पाया। दोबारा माइक दबाएँ।" }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { listening = false }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            recognizer.startListening(intent)
        } catch (_: Exception) { listening = false; replyText = "माइक शुरू नहीं हो पाया। अनुमति जाँचें।" }
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) startListening() else replyText = "आवाज़ सुनने के लिए Microphone permission चाहिए।" }
    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> replyText = if (granted) "Camera permission मिल गई। अब टॉर्च कमांड दोहराएँ।" else "टॉर्च के लिए Camera permission चाहिए।" }


    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel, onPrimary = Bg, onSurface = WhiteText)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            when (screen) {
                "settings" -> SettingsPage(
                    assistantName, { assistantName = it }, userName, { userName = it }, language, { language = it },
                    geminiKey, { geminiKey = it; geminiStatus = if (it.isBlank()) "Not configured" else "Key entered • Not validated" },
                    youtubeKey, { youtubeKey = it; youtubeStatus = "Unverified" }, model, { model = it }, personality, { personality = it }, customPersonality, { customPersonality = it }, voice, { voice = it },
                    youtubeEnabled, { youtubeEnabled = it }, showGemini, { showGemini = it }, showYoutube, { showYoutube = it }, geminiStatus, youtubeStatus, validationBusy,
                    onBack = { screen = "home" }, onSave = {
                        prefs.edit().putString("assistant_name", assistantName).putString("user_name", userName).putString("language", language).putString("gemini_key", geminiKey).putString("youtube_key", youtubeKey).putString("model", model).putString("personality", personality).putString("custom_personality", customPersonality).putString("voice", voice).putBoolean("youtube_enabled", youtubeEnabled).apply()
                        tts.language = if (language.startsWith("English")) Locale.US else Locale("hi", "IN")
                        replyText = "सेटिंग्स सेव हो गईं।"; screen = "home"
                    }, onPasteGemini = { geminiKey = clipboard.getText()?.text.orEmpty(); geminiStatus = "Key entered • Not validated" },
                    onPasteYoutube = { youtubeKey = clipboard.getText()?.text.orEmpty(); youtubeStatus = "Unverified" },
                    onValidateGemini = {
                        if (geminiKey.isBlank()) geminiStatus = "पहले API key डालें" else scope.launch {
                            validationBusy = true; geminiStatus = "Validating…"
                            geminiStatus = withContext(Dispatchers.IO) { validateUrl("https://generativelanguage.googleapis.com/v1beta/models?key=" + Uri.encode(geminiKey)) }
                            validationBusy = false
                        }
                    }, onValidateYoutube = {
                        if (youtubeKey.isBlank()) youtubeStatus = "पहले API key डालें" else scope.launch {
                            validationBusy = true; youtubeStatus = "Validating…"
                            youtubeStatus = withContext(Dispatchers.IO) { validateUrl("https://www.googleapis.com/youtube/v3/videos?part=id&id=dQw4w9WgXcQ&key=" + Uri.encode(youtubeKey)) }
                            validationBusy = false
                        }
                    }, onManagePermissions = { context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + context.packageName))) },
                    onAllowMic = { micPermission.launch(Manifest.permission.RECORD_AUDIO) }, onAllowCamera = { cameraPermission.launch(Manifest.permission.CAMERA) }, onViewMemories = { memoryText = context.getSharedPreferences("mark_memory", Context.MODE_PRIVATE).getString("notes", "") ?: ""; screen = "memories" },
                    onClearMemories = { context.getSharedPreferences("mark_memory", Context.MODE_PRIVATE).edit().clear().apply(); memoryText = ""; replyText = "सारी सेव की गई यादें साफ कर दी गईं।" }
                )
                "history" -> SimplePage("CONVERSATION HISTORY", { screen = "home" }) {
                    OutlinedTextField(value = historyQuery, onValueChange = { historyQuery = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search past conversations…") })
                    if (history.isEmpty()) Text("अभी कोई सेव बातचीत नहीं है।", color = Muted)
                    history.filter { it.contains(historyQuery, ignoreCase = true) }.reversed().forEach { Text(it, color = WhiteText, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).background(Panel, RoundedCornerShape(12.dp)).padding(12.dp)) }
                    Button(onClick = { history.clear(); persistHistory(); historyQuery = "" }) { Text("CLEAR HISTORY") }
                }
                "memories" -> SimplePage("MEMORY CORE", { screen = "settings" }) { Text(if (memoryText.isBlank()) "कोई सेव नोट नहीं है।" else memoryText, color = WhiteText) }
                "sleep" -> SimplePage("SLEEP MODE", { screen = "home" }) { Text("स्लीप स्क्रीन। वापस आने के लिए Back दबाएँ।", color = Muted) }
                else -> Dashboard(assistantName, userName, listening, heardText, replyText, history, onSettings = { screen = "settings" }, onMic = {
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startListening() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                }, onVision = { imagePicker.launch("image/*") }, onHistory = { screen = "history" }, onSleep = { screen = "sleep" }, onPermission = { cameraPermission.launch(Manifest.permission.CAMERA) })
            }
        }
    }
}

private fun requestedGeminiModelId(selectedModel: String): String = when {
    selectedModel.contains("2.5 Pro", ignoreCase = true) -> "gemini-2.5-pro"
    selectedModel.contains("2.0 Flash", ignoreCase = true) -> "gemini-2.0-flash"
    else -> "gemini-2.5-flash"
}

/** Lists models available to this API key and prioritizes the selected model, then Flash models. */
private fun availableGeminiModelIds(apiKey: String, selectedModel: String): List<String> {
    var connection: HttpURLConnection? = null
    return try {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models?key=" + Uri.encode(apiKey))
        connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10000
            readTimeout = 15000
        }
        if (connection.responseCode !in 200..299) return emptyList()
        val jsonText = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        val models = JSONObject(jsonText).optJSONArray("models") ?: return emptyList()
        val supported = mutableListOf<String>()
        for (i in 0 until models.length()) {
            val item = models.optJSONObject(i) ?: continue
            val methods = item.optJSONArray("supportedGenerationMethods") ?: continue
            var canGenerate = false
            for (j in 0 until methods.length()) {
                if (methods.optString(j) == "generateContent") canGenerate = true
            }
            if (!canGenerate) continue
            val name = item.optString("name").removePrefix("models/")
            if (name.isNotBlank() && !name.contains("embedding", ignoreCase = true)) supported.add(name)
        }
        val preferred = requestedGeminiModelId(selectedModel)
        val ordered = mutableListOf<String>()
        // Prefer known stable model IDs when the API explicitly lists them. Do not rely on
        // the arbitrary order returned by the models endpoint, and do not truncate the
        // candidate list before the known fallbacks are tried.
        if (preferred in supported) ordered.add(preferred)
        listOf("gemini-2.5-flash", "gemini-2.0-flash", "gemini-2.5-pro").forEach { id ->
            if (id in supported && id !in ordered) ordered.add(id)
        }
        supported.filter { it.contains("flash", ignoreCase = true) && !it.contains("preview", ignoreCase = true) }
            .forEach { if (it !in ordered) ordered.add(it) }
        supported.filter { !it.contains("preview", ignoreCase = true) }
            .forEach { if (it !in ordered) ordered.add(it) }
        // Preview/other listed models are last-resort candidates only.
        supported.forEach { if (it !in ordered) ordered.add(it) }
        ordered
    } catch (_: Exception) {
        emptyList()
    } finally {
        connection?.disconnect()
    }
}

private data class GeminiHttpResult(val status: Int, val body: String)

private fun postGeminiContent(apiKey: String, modelId: String, body: JSONObject): GeminiHttpResult {
    var connection: HttpURLConnection? = null
    return try {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$modelId:generateContent?key=" + Uri.encode(apiKey))
        connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val status = connection.responseCode
        val stream = if (status in 200..299) connection.inputStream else connection.errorStream
        GeminiHttpResult(status, stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty())
    } finally {
        connection?.disconnect()
    }
}

private fun geminiErrorMessage(status: Int, responseText: String): String {
    val message = try { JSONObject(responseText.ifBlank { "{}" }).optJSONObject("error")?.optString("message").orEmpty() } catch (_: Exception) { "" }
    return when (status) {
        400 -> "Gemini request में समस्या है। Settings में AI Model चुनें और API key validate करें."
        401, 403 -> "Gemini API key या access में समस्या है। API key, API enablement और key restrictions जाँचें।"
        404 -> "Gemini का कोई उपलब्ध model इस request के लिए नहीं मिला (404). Google AI Studio में API key और उपलब्ध models जाँचें।" + if (message.isNotBlank()) "\nDetails: $message" else ""
        429 -> "Gemini की request limit पूरी हो गई है। थोड़ी देर बाद फिर कोशिश करें।"
        else -> "Gemini server error ($status)." + if (message.isNotBlank()) " $message" else " API settings जाँचें।"
    }
}

private fun askGemini(apiKey: String, selectedModel: String, personality: String, assistantName: String, userName: String, language: String, userText: String): String {
    return try {
        val systemPrompt = "You are a warm, loyal, friendly personal Android assistant named $assistantName. Address the user as $userName, like a trusted friend and teammate. Reply naturally in Hindi/Hinglish by default, with empathy, light humor when appropriate, and clear simple explanations. Preferred language: $language. Personality mode: $personality. Be concise but useful. Never claim to have changed phone settings or performed actions unless the Android action was actually performed. For unsafe or unavailable actions, explain the real limitation honestly."
        val parts = JSONArray().put(JSONObject().put("text", "$systemPrompt\n\nUser: $userText"))
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("temperature", 0.7).put("maxOutputTokens", 700))
        val preferred = requestedGeminiModelId(selectedModel)
        val candidates = (availableGeminiModelIds(apiKey, selectedModel) + listOf(preferred, "gemini-2.5-flash", "gemini-2.0-flash", "gemini-2.5-pro")).distinct()
        var last404: GeminiHttpResult? = null
        for (modelId in candidates) {
            val result = try { postGeminiContent(apiKey, modelId, body) } catch (_: Exception) {
                return "Gemini से कनेक्ट नहीं हो पाया। Internet, API key और नेटवर्क जाँचें।"
            }
            if (result.status == 404) { last404 = result; continue }
            if (result.status !in 200..299) return geminiErrorMessage(result.status, result.body)
            val json = JSONObject(result.body.ifBlank { "{}" })
            val responseParts = json.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            val answer = responseParts?.optJSONObject(0)?.optString("text").orEmpty().trim()
            return if (answer.isBlank()) "Gemini से खाली जवाब मिला। दोबारा पूछें।" else answer
        }
        geminiErrorMessage(404, last404?.body.orEmpty())
    } catch (_: Exception) {
        "Gemini से कनेक्ट नहीं हो पाया। Internet, API key और नेटवर्क जाँचें।"
    }
}

private fun searchYoutube(apiKey: String, query: String): String? {
    var connection: HttpURLConnection? = null
    return try {
        val url = URL("https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=1&q=" + Uri.encode(query) + "&key=" + Uri.encode(apiKey))
        connection = (url.openConnection() as HttpURLConnection).apply { connectTimeout = 10000; readTimeout = 10000 }
        if (connection.responseCode !in 200..299) return null
        val text = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        val items = JSONObject(text).optJSONArray("items") ?: return null
        val id = items.optJSONObject(0)?.optJSONObject("id")?.optString("videoId").orEmpty()
        if (id.isBlank()) null else "https://www.youtube.com/watch?v=$id"
    } catch (_: Exception) { null } finally { connection?.disconnect() }
}

private fun askGeminiVision(apiKey: String, selectedModel: String, userName: String, language: String, imageBytes: ByteArray, mimeType: String): String {
    return try {
        val prompt = "You are a friendly personal assistant. Address user as $userName. Reply in natural Hindi/Hinglish unless English is requested. Preferred language: $language. Describe this image and answer: Is tasveer mein kya hai?"
        val parts = JSONArray()
            .put(JSONObject().put("text", prompt))
            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", mimeType).put("data", Base64.encodeToString(imageBytes, Base64.NO_WRAP))))
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("temperature", 0.5).put("maxOutputTokens", 700))
        val preferred = requestedGeminiModelId(selectedModel)
        val candidates = (availableGeminiModelIds(apiKey, selectedModel) + listOf(preferred, "gemini-2.5-flash", "gemini-2.0-flash", "gemini-2.5-pro")).distinct()
        var last404: GeminiHttpResult? = null
        for (modelId in candidates) {
            val result = try { postGeminiContent(apiKey, modelId, body) } catch (_: Exception) {
                return "Gemini Vision से कनेक्ट नहीं हो पाया। इंटरनेट और API key जाँचें।"
            }
            if (result.status == 404) { last404 = result; continue }
            if (result.status !in 200..299) return "Gemini Vision: " + geminiErrorMessage(result.status, result.body)
            val responseParts = JSONObject(result.body.ifBlank { "{}" }).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            return responseParts?.optJSONObject(0)?.optString("text")?.takeIf { it.isNotBlank() } ?: "तस्वीर का जवाब खाली आया। दोबारा कोशिश करें।"
        }
        "Gemini Vision: " + geminiErrorMessage(404, last404?.body.orEmpty())
    } catch (_: Exception) {
        "Gemini Vision से कनेक्ट नहीं हो पाया। इंटरनेट और API key जाँचें।"
    }
}

private fun validateUrl(url: String): String {
    var connection: HttpURLConnection? = null
    return try {
        connection = (URL(url).openConnection() as HttpURLConnection).apply { requestMethod = "GET"; connectTimeout = 10000; readTimeout = 10000 }
        when (connection.responseCode) {
            in 200..299 -> "Valid • API responded successfully"
            403 -> "403 • API/key/quota restriction; check Google Cloud settings"
            400, 401 -> "Invalid key or request (${connection.responseCode})"
            else -> "HTTP ${connection.responseCode} • Check key and API settings"
        }
    } catch (_: Exception) { "Network error • Check internet and retry" } finally { connection?.disconnect() }
}

@Composable
private fun Dashboard(name: String, userName: String, listening: Boolean, heard: String, reply: String, conversationHistory: List<String>, onSettings: () -> Unit, onMic: () -> Unit, onVision: () -> Unit, onHistory: () -> Unit, onSleep: () -> Unit, onPermission: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "orb")
    val pulse by transition.animateFloat(initialValue = 0.97f, targetValue = 1.035f, animationSpec = infiniteRepeatable(tween(1450), RepeatMode.Reverse), label = "pulse")
    val context = LocalContext.current
    Box(Modifier.fillMaxSize().background(Color(0xFF030914))) {
        Canvas(Modifier.fillMaxSize()) {
            val step = 48.dp.toPx()
            var x = 0f
            while (x <= size.width) {
                drawLine(Color(0xFF123342).copy(alpha = 0.42f), Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
                x += step
            }
            var y = 0f
            while (y <= size.height) {
                drawLine(Color(0xFF123342).copy(alpha = 0.42f), Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
                y += step
            }
        }
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xAA06182B), Color(0x6610102D), Color.Transparent, Color(0xAA02050A)))).padding(horizontal = 16.dp, vertical = 12.dp)) {
            Row(Modifier.fillMaxWidth().height(70.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).border(2.dp, Cyan, CircleShape).background(Brush.radialGradient(listOf(Color(0xFF153D58), Color(0xFF08111E))), CircleShape), contentAlignment = Alignment.Center) {
                    Text("✣", color = Cyan, fontSize = 25.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, color = WhiteText, fontSize = 24.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.5.sp)
                    Text(if (listening) "● LISTENING — I'M HERE" else "● CALM — SYSTEM ONLINE", color = Cyan, fontSize = 11.sp, letterSpacing = 0.5.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()), color = WhiteText, fontSize = 21.sp)
                    Text("▂▃▅", color = Muted, fontSize = 11.sp)
                }
                Spacer(Modifier.width(8.dp))
                Button(onClick = onSettings, modifier = Modifier.size(48.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF101D2A)), contentPadding = PaddingValues(0.dp)) { Text("☷", color = Cyan, fontSize = 25.sp) }
            }
            Spacer(Modifier.height(6.dp))
            Box(Modifier.fillMaxWidth().weight(0.95f), contentAlignment = Alignment.Center) {
                Box(Modifier.size(292.dp).scale(pulse).border(1.dp, Cyan.copy(alpha = 0.58f), CircleShape), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(254.dp).border(2.dp, Color(0xFF16738D).copy(alpha = 0.75f), CircleShape).padding(16.dp).border(1.dp, Color(0xFF1C6377), CircleShape), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(206.dp).background(Brush.radialGradient(listOf(Color(0xFF124D67), Color(0xFF111C4A), Color(0xFF170F30), Color(0xFF030914))), CircleShape).border(1.dp, Color(0xFF1B596E), CircleShape), contentAlignment = Alignment.Center) {
                            Box(Modifier.size(96.dp).background(Brush.radialGradient(listOf(Color(0xFF25E6F4), Color(0xFF078EBC), Color(0xFF063A63))), CircleShape), contentAlignment = Alignment.Center) {
                                Text(if (listening) "◉" else "✣", color = Color(0xFF062131), fontSize = 52.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                Box(Modifier.align(Alignment.TopCenter).padding(top = 16.dp).size(8.dp).background(Cyan, CircleShape))
                Box(Modifier.align(Alignment.CenterEnd).padding(end = 28.dp).size(9.dp).background(Color(0xFF66B8FF), CircleShape))
                Box(Modifier.align(Alignment.BottomStart).padding(start = 32.dp, bottom = 28.dp).size(7.dp).background(Cyan, CircleShape))
                Box(Modifier.align(Alignment.CenterStart).padding(start = 28.dp).size(8.dp).background(Color(0xFF65B9FF), CircleShape))
            }
            Text("CONVERSATION", color = Muted, fontSize = 12.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(8.dp))
            Column(Modifier.fillMaxWidth().weight(1.05f).background(Color(0xF0091722), RoundedCornerShape(22.dp)).border(1.dp, Color(0xFF164859), RoundedCornerShape(22.dp)).padding(13.dp)) {
                if (conversationHistory.isEmpty()) {
                    Text("You  •  ${SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())}", color = Muted, fontSize = 11.sp)
                    Text(heard, color = WhiteText, modifier = Modifier.fillMaxWidth().padding(top = 5.dp, bottom = 14.dp).background(Color(0xFF0C3542), RoundedCornerShape(13.dp)).padding(12.dp))
                    Text(name, color = Cyan, fontSize = 11.sp)
                    Text(reply, color = WhiteText, modifier = Modifier.padding(top = 5.dp))
                } else {
                    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(conversationHistory.takeLast(5)) { entry ->
                            val lines = entry.split("\n", limit = 2)
                            Column(Modifier.fillMaxWidth()) {
                                Text(lines.firstOrNull().orEmpty(), color = Muted, fontSize = 11.sp)
                                Text(lines.getOrElse(1) { "" }, color = WhiteText, modifier = Modifier.fillMaxWidth().padding(top = 4.dp).background(Color(0xFF0C3542), RoundedCornerShape(13.dp)).padding(11.dp))
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = onSleep, modifier = Modifier.weight(1f), shape = RoundedCornerShape(28.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF282333)), contentPadding = PaddingValues(horizontal = 5.dp, vertical = 13.dp)) { Text("⏻  SLEEP", color = Magenta, fontSize = 10.sp) }
                Button(onClick = onVision, modifier = Modifier.weight(1f), shape = RoundedCornerShape(28.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF152D43)), contentPadding = PaddingValues(horizontal = 5.dp, vertical = 13.dp)) { Text("▣  VISION", color = Color(0xFF7BCBFF), fontSize = 10.sp) }
                Button(onClick = onMic, modifier = Modifier.size(70.dp), shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = Cyan), contentPadding = PaddingValues(0.dp)) { Text("🎙", fontSize = 25.sp, color = Bg) }
                Button(onClick = onHistory, modifier = Modifier.weight(1.2f), shape = RoundedCornerShape(28.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF20232E)), contentPadding = PaddingValues(horizontal = 5.dp, vertical = 13.dp)) { Text("◴  HISTORY", color = WhiteText, fontSize = 10.sp) }
            }
            Spacer(Modifier.height(8.dp))
            Text("Wake phrase ‘Hey Jarvis’ अभी माइक बटन से शुरू होता है; background listening सक्रिय नहीं है।", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
        }
    }
}

@Composable
private fun SettingsPage(
    assistantName: String, onAssistantName: (String) -> Unit, userName: String, onUserName: (String) -> Unit, language: String, onLanguage: (String) -> Unit,
    geminiKey: String, onGeminiKey: (String) -> Unit, youtubeKey: String, onYoutubeKey: (String) -> Unit, model: String, onModel: (String) -> Unit, personality: String, onPersonality: (String) -> Unit, customPersonality: String, onCustomPersonality: (String) -> Unit, voice: String, onVoice: (String) -> Unit,
    youtubeEnabled: Boolean, onYoutubeEnabled: (Boolean) -> Unit, showGemini: Boolean, onShowGemini: (Boolean) -> Unit, showYoutube: Boolean, onShowYoutube: (Boolean) -> Unit, geminiStatus: String, youtubeStatus: String, busy: Boolean,
    onBack: () -> Unit, onSave: () -> Unit, onPasteGemini: () -> Unit, onPasteYoutube: () -> Unit, onValidateGemini: () -> Unit, onValidateYoutube: () -> Unit, onManagePermissions: () -> Unit, onAllowMic: () -> Unit, onAllowCamera: () -> Unit, onViewMemories: () -> Unit, onClearMemories: () -> Unit
) {
    val context = LocalContext.current
    LazyColumn(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF09182B), Color(0xFF10102B), Bg, Color.Black))).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                OutlinedButton(onClick = onBack) { Text("‹ BACK") }
                Text("Settings", color = WhiteText, fontSize = 25.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                TextButton(onClick = onSave) { Text("SAVE", color = Cyan, fontWeight = FontWeight.Bold, letterSpacing = 2.sp) }
            }
        }
        item { SectionTitle("Assistant Profile", "◉"); PanelCard {
            LabeledField("ASSISTANT NAME", assistantName, onAssistantName, "MARK or JARVIS")
            LabeledField("USER NAME", userName, onUserName, "Ajju Bhai")
            ChoiceRow("PREFERRED LANGUAGE", listOf("Hindi + Hinglish", "Hindi", "English"), language, onLanguage)
            ChoiceRow("PERSONALITY", listOf("Friendly", "Helpful", "Assistant Mode", "Custom"), personality, onPersonality)
            if (personality == "Custom") LabeledField("CUSTOM PERSONALITY INSTRUCTIONS", customPersonality, onCustomPersonality, "Describe how your assistant should talk")
        } }
        item { SectionTitle("API Key", "⚿"); PanelCard {
            LabeledField("GEMINI API KEY", geminiKey, onGeminiKey, "Paste Gemini API key", !showGemini)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onPasteGemini) { Text("Paste from clipboard", color = Cyan) }
                TextButton(onClick = { onShowGemini(!showGemini) }) { Text(if (showGemini) "Hide key" else "Show key", color = Muted) }
            }
            ChoiceRow("AI MODEL", listOf("Auto (Recommended)", "Gemini 2.5 Flash", "Gemini 2.5 Pro", "Gemini 2.0 Flash"), model, onModel)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = onValidateGemini, enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF103A47))) { Text("VALIDATE KEY") }
                Spacer(Modifier.width(10.dp)); Text(geminiStatus, color = if (geminiStatus.startsWith("Valid")) Color(0xFF42E7A5) else Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
            }
            Text("Production note: API keys stored on the phone are not suitable for public distribution. Use a secure backend for a published app.", color = Muted, fontSize = 11.sp)
        } }
        item { SectionTitle("Voice", "♬"); PanelCard {
            Text("Select voice (available only if your configured service supports it)", color = Muted, fontSize = 12.sp)
            val voices = listOf("Puck", "Charon", "Kore", "Fenrir", "Aoede", "Leda", "Orus", "Zephyr")
            voices.chunked(4).forEach { group -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) { group.forEach { v -> FilterChip(selected = voice == v, onClick = { onVoice(v) }, label = { Text(v, fontSize = 11.sp) }) } } }
            Text("Android Text-to-Speech uses the phone's installed voice. These names are saved as a preference and do not switch Android voices by themselves.", color = Muted, fontSize = 11.sp)
        } }
        item { SectionTitle("Permissions", "▣"); PanelCard {
            val micGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            val cameraGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
            Text("${if (micGranted) "✓" else "○"} Microphone: ${if (micGranted) "Granted" else "Missing"}", color = if (micGranted) Color(0xFF42E7A5) else WhiteText)
            Text("${if (cameraGranted) "✓" else "○"} Camera / flashlight: ${if (cameraGranted) "Granted" else "Missing"}", color = if (cameraGranted) Color(0xFF42E7A5) else WhiteText)
            Text("Internet: declared in app manifest; network access still depends on connectivity.", color = Muted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Button(onClick = onAllowMic, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)) { Text("ALLOW MIC", fontSize = 11.sp) }; Button(onClick = onAllowCamera, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)) { Text("ALLOW CAMERA", fontSize = 11.sp) } }; OutlinedButton(onClick = onManagePermissions, modifier = Modifier.fillMaxWidth()) { Text("MANAGE PERMISSIONS") }
            Text("Screen unlock cannot be bypassed. Use Android PIN, pattern, biometric or system security screen.", color = Muted, fontSize = 11.sp)
        } }
        item { SectionTitle("Memory Core", "▤"); PanelCard {
            Text("Short-term conversation buffer + local notes and preferences", color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick = onClearMemories, modifier = Modifier.weight(1f)) { Text("CLEAR", color = Color(0xFFFF628A)) }; Button(onClick = onViewMemories, modifier = Modifier.weight(1f)) { Text("VIEW MEMORIES") } }
            Text("Memory is stored locally on this device. Avoid saving sensitive information.", color = Muted, fontSize = 11.sp)
        } }
        item { SectionTitle("YouTube Automation", "▷"); PanelCard {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) { Text("Enable YouTube Automation", color = WhiteText); Switch(checked = youtubeEnabled, onCheckedChange = onYoutubeEnabled) }
            Text("YouTube Data API v3 key for searching songs, videos and playlists.", color = Muted, fontSize = 12.sp)
            LabeledField("YOUTUBE API KEY", youtubeKey, onYoutubeKey, "Paste YouTube API key", !showYoutube)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onPasteYoutube) { Text("Paste from clipboard", color = Cyan) }
                TextButton(onClick = { onShowYoutube(!showYoutube) }) { Text(if (showYoutube) "Hide key" else "Show key", color = Muted) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) { Button(onClick = onValidateYoutube, enabled = !busy) { Text("VALIDATE KEY") }; Spacer(Modifier.width(10.dp)); Text("Status: $youtubeStatus", color = if (youtubeStatus.startsWith("Valid")) Color(0xFF42E7A5) else Muted, fontSize = 11.sp, modifier = Modifier.weight(1f)) }
        } }
        item { SectionTitle("Mobile Control", "▯"); PanelCard {
            listOf("‘Turn flashlight on / off’", "‘Set brightness to 50%’ / ‘Increase brightness’", "‘Volume up / down’", "‘Open Instagram’, ‘Open WhatsApp’, ‘Open Spotify’", "‘Send WhatsApp to Rahul saying I will be late’ — draft/review only", "‘Call Rahul’ — opens dialer; no silent calling", "‘Remember my gym starts at 6 PM’, ‘Forget routine’").forEach { Text("▪  $it", color = WhiteText, modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp)) }
            Divider(color = Color(0xFF1B3A45), modifier = Modifier.padding(vertical = 8.dp))
            Text("WhatsApp confirmation policy: Active", color = Color(0xFF42E7A5), fontWeight = FontWeight.Bold)
            Text("This build does not silently send messages or initiate calls. Some controls require Android permission or system confirmation.", color = Muted, fontSize = 11.sp)
        } }
        item { Text("Gemini text chat uses the API key saved on this phone. Image understanding, true always-on wake-word listening, background routines, and YouTube Data API search are not yet implemented. API keys stored on-device are for personal testing only; use a secure backend before public distribution.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 24.dp)) }
    }
}

@Composable
private fun SectionTitle(title: String, symbol: String) { Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) { Box(Modifier.size(42.dp).background(Color(0xFF0B2534), RoundedCornerShape(12.dp)).border(1.dp, Color(0xFF1D5264), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Text(symbol, color = Cyan, fontSize = 20.sp) }; Spacer(Modifier.width(12.dp)); Text(title, color = WhiteText, fontSize = 19.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp) } }

@Composable
private fun PanelCard(content: @Composable ColumnScope.() -> Unit) { Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content) } }

@Composable
private fun LabeledField(label: String, value: String, onValue: (String) -> Unit, placeholder: String, hidden: Boolean = false) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(label, color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
        OutlinedTextField(value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth(), placeholder = { Text(placeholder, color = Muted) }, singleLine = true, visualTransformation = if (hidden) PasswordVisualTransformation() else VisualTransformation.None, keyboardOptions = KeyboardOptions(keyboardType = if (label.contains("KEY")) KeyboardType.Password else KeyboardType.Text), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Color(0xFF21414D), focusedTextColor = WhiteText, unfocusedTextColor = WhiteText, cursorColor = Cyan))
    }
}

@Composable
private fun ChoiceRow(label: String, choices: List<String>, selected: String, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Column {
        Text(label, color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selected, color = WhiteText, modifier = Modifier.weight(1f)); Text("⌄", color = Cyan) }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { choices.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onSelect(option); expanded = false }) } }
        }
    }
}

@Composable
private fun SimplePage(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).padding(18.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { OutlinedButton(onClick = onBack) { Text("‹ BACK") }; Spacer(Modifier.width(14.dp)); Text(title, color = WhiteText, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(16.dp)); Column(Modifier.fillMaxSize(), content = content)
    }
}
