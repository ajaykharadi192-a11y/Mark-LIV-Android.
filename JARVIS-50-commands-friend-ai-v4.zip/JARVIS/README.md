# JARVIS / MARK Android Assistant — V4 source project

This is the source project for a personal Android assistant with a futuristic cyan/neon arc-reactor-inspired UI, Hindi/Hinglish speech input, spoken replies, Gemini text chat, image understanding, phone intents, local notes/tasks, YouTube search, and a GitHub Actions debug-APK workflow.

## Build APK with the repository ZIP workflow
1. Upload this archive to the root of your GitHub repository using the exact name `JARVIS-50-commands-friend-ai-v4.zip` if your existing workflow searches for `JARVIS-50-commands-*.zip` and unpacks the `JARVIS/` folder.
2. Commit the upload, then open **Actions → Build MARK APK** and open the newest run.
3. If it succeeds, download the `JARVIS-debug-apk` artifact from that run.
4. If it fails, open the failed `Unpack and build APK` step and inspect the first Kotlin error.

## Commands / actions
The command router covers the requested 50 command categories: greeting/wake phrase in a recognized utterance, assistant status, Hindi/English selection, speech output, stop speaking, YouTube, WhatsApp, camera, phone settings, security/lock settings, flashlight on/off, volume up/down, battery, dialer/call preparation, contacts picker, WhatsApp message draft, SMS draft, contact creation form, weather search, general questions through Gemini, explanations through Gemini, translation page, email draft, time, date, timer screen, alarm screen, local notes, song search, video search, next media track, pause media, joke, remember note, read notes, shopping list, task list, conversation history, web search, news, local weather search, Maps directions, connectivity settings, image selection + Gemini image analysis, AI + web search, save note, phone/assistant settings, and status.

## Honest limitations
- The microphone button uses Android SpeechRecognizer on demand. The wake phrase can be understood when it is part of a recognized utterance, but **this is not an always-on background wake-word engine**. Android background microphone use requires a user-started foreground service, persistent notification, permissions, and device-specific battery settings; those are not implemented here.
- Phone calls, WhatsApp/SMS/email messages, alarms, and timers open the appropriate app/system screen for user review. The app does not silently call or send messages.
- Unlocking the device is not bypassed; Android's PIN, pattern, biometric, and security screens remain in control.
- Brightness and flashlight depend on system permissions and device hardware. App launches depend on apps being installed.
- Notes, tasks, shopping list, settings, and current-session history are stored locally with app preferences/state. This version does not use Room Database and session history is not a persistent conversation archive.
- Gemini text chat and image analysis call the Google Gemini API directly using the key saved in this personal test build. YouTube search uses the Data API when a key is configured and falls back to official YouTube search links. On-device API keys are not suitable for a public production app; use a secure backend before distributing publicly.
- Voice options are saved preferences; Android's installed TTS voice is what actually speaks. The app does not provide Gemini Live voice/audio streaming.
- This source ZIP is not an APK. Build verification must be performed by GitHub Actions. The local build could not run in this environment because the Gradle distribution could not be downloaded due to network restrictions.
