# MARK LIV — Android port

This folder is an Android-compatible port of the original MARK LIV project.

## What is preserved
- MARK LIV branding and assistant flow
- Gemini-based responses
- Text input
- Android text-to-speech
- Mobile-friendly UI

## What is different on Android
The original project uses PyQt6, sounddevice, pyautogui, Playwright, Windows APIs and desktop screen/mouse controls. Those APIs cannot be carried into an Android APK unchanged. Android uses its own permission and app-control model, so those desktop-only tools remain in the original project but are not imported by the Android entry point.

## Build
On a Linux/WSL machine with Buildozer:

```bash
pip install buildozer
buildozer android debug
```

The APK will be produced under `bin/`.

## API key
The supplied desktop ZIP contained a Gemini API key. It was intentionally NOT copied into this Android port. Launch the app and use **API KEY** to enter your own key.
