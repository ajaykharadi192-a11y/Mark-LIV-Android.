import json, os, threading
from pathlib import Path

import requests
from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.lang import Builder
from kivy.properties import StringProperty
from kivy.uix.boxlayout import BoxLayout

KV = r'''
#:import dp kivy.metrics.dp

<Root>:
    orientation: 'vertical'
    padding: dp(14)
    spacing: dp(10)
    canvas.before:
        Color:
            rgba: .035, .045, .06, 1
        Rectangle:
            pos: self.pos
            size: self.size
    Label:
        text: 'MARK LIV'
        font_size: '30sp'
        bold: True
        size_hint_y: None
        height: dp(55)
    Label:
        text: root.status
        font_size: '14sp'
        size_hint_y: None
        height: dp(34)
        text_size: self.width, None
    TextInput:
        id: chat
        text: root.reply
        readonly: True
        multiline: True
        font_size: '16sp'
        padding: dp(12), dp(12)
        background_color: .08, .09, .12, 1
        foreground_color: .92, .94, 1, 1
    TextInput:
        id: prompt
        hint_text: 'Type your command...'
        multiline: False
        font_size: '17sp'
        size_hint_y: None
        height: dp(52)
        on_text_validate: root.send_text(self.text)
    BoxLayout:
        size_hint_y: None
        height: dp(56)
        spacing: dp(8)
        Button:
            text: '🎙  VOICE'
            font_size: '17sp'
            on_release: root.start_voice()
        Button:
            text: 'SEND'
            font_size: '17sp'
            on_release: root.send_text(prompt.text)
    BoxLayout:
        size_hint_y: None
        height: dp(48)
        spacing: dp(8)
        Button:
            text: 'API KEY'
            on_release: root.set_key()
        Button:
            text: 'CLEAR'
            on_release: root.clear_chat()
'''

class Root(BoxLayout):
    status = StringProperty('Ready')
    reply = StringProperty('')
    _voice_dialog = None

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.api_key = self.load_key()
        if not self.api_key:
            self.status = 'Set your Gemini API key first.'

    @property
    def key_path(self):
        return Path(App.get_running_app().user_data_dir) / 'settings.json'

    def load_key(self):
        try:
            return json.loads(self.key_path.read_text()).get('gemini_api_key', '')
        except Exception:
            return ''

    def save_key(self, key):
        self.key_path.parent.mkdir(parents=True, exist_ok=True)
        self.key_path.write_text(json.dumps({'gemini_api_key': key.strip()}))
        self.api_key = key.strip()

    def set_key(self):
        from kivy.uix.popup import Popup
        from kivy.uix.textinput import TextInput
        from kivy.uix.button import Button
        box = BoxLayout(orientation='vertical', padding=12, spacing=8)
        inp = TextInput(text=self.api_key, password=True, multiline=False)
        btn = Button(text='SAVE', size_hint_y=None, height=48)
        box.add_widget(inp); box.add_widget(btn)
        pop = Popup(title='Gemini API key', content=box, size_hint=(.92, .35))
        def save(_):
            self.save_key(inp.text); pop.dismiss(); self.status='API key saved.'
        btn.bind(on_release=save)
        pop.open()

    def clear_chat(self):
        self.reply = ''
        self.status = 'Ready'

    def send_text(self, text):
        text = (text or '').strip()
        if not text: return
        if not self.api_key:
            self.status = 'Please set the Gemini API key.'
            return
        self.reply += ('\n\n' if self.reply else '') + 'You: ' + text + '\nMARK: thinking...'
        self.status = 'Thinking...'
        threading.Thread(target=self._ask, args=(text,), daemon=True).start()

    def _ask(self, text):
        try:
            url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent'
            payload = {'contents': [{'parts': [{'text': text}]}]}
            r = requests.post(url, params={'key': self.api_key}, json=payload, timeout=30)
            r.raise_for_status()
            data = r.json()
            answer = data['candidates'][0]['content']['parts'][0]['text']
            Clock.schedule_once(lambda dt: self._answer(answer), 0)
        except Exception as e:
            Clock.schedule_once(lambda dt: self._answer('Error: ' + str(e)), 0)

    def _answer(self, answer):
        if '\nMARK: thinking...' in self.reply:
            self.reply = self.reply.replace('\nMARK: thinking...', '\nMARK: ' + answer, 1)
        else:
            self.reply += '\nMARK: ' + answer
        self.status = 'Ready'
        self.speak(answer)

    def speak(self, text):
        try:
            from jnius import autoclass
            PythonActivity = autoclass('org.kivy.android.PythonActivity')
            activity = PythonActivity.mActivity
            Context = autoclass('android.content.Context')
            TextToSpeech = autoclass('android.speech.tts.TextToSpeech')
            Locale = autoclass('java.util.Locale')
            def listener(status):
                if status == TextToSpeech.SUCCESS:
                    self._tts.setLanguage(Locale.getDefault())
                    self._tts.speak(text, TextToSpeech.QUEUE_FLUSH, None, 'mark-liv')
            self._tts = TextToSpeech(activity, listener)
        except Exception:
            pass

    def start_voice(self):
        try:
            from jnius import autoclass, PythonJavaClass, java_method
            PythonActivity = autoclass('org.kivy.android.PythonActivity')
            Intent = autoclass('android.content.Intent')
            RecognizerIntent = autoclass('android.speech.RecognizerIntent')
            SpeechRecognizer = autoclass('android.speech.SpeechRecognizer')
            RecognitionListener = autoclass('android.speech.RecognitionListener')
            Bundle = autoclass('android.os.Bundle')

            root = self
            class Listener(PythonJavaClass):
                __javainterfaces__ = ['android/speech/RecognitionListener']
                @java_method('()V')
                def onReadyForSpeech(self):
                    Clock.schedule_once(lambda dt: setattr(root, 'status', 'Listening...'), 0)
                @java_method('()V')
                def onBeginningOfSpeech(self):
                    pass
                @java_method('([B)V')
                def onBufferReceived(self, buffer):
                    pass
                @java_method('(F)V')
                def onRmsChanged(self, rms):
                    pass
                @java_method('()V')
                def onEndOfSpeech(self):
                    Clock.schedule_once(lambda dt: setattr(root, 'status', 'Processing voice...'), 0)
                @java_method('(I)V')
                def onError(self, error):
                    Clock.schedule_once(lambda dt: setattr(root, 'status', 'Voice error: ' + str(error)), 0)
                @java_method('(Landroid/os/Bundle;)V')
                def onResults(self, results):
                    arr = results.getStringArrayList(RecognizerIntent.EXTRA_RESULTS)
                    if arr and arr.size() > 0:
                        text = str(arr.get(0))
                        Clock.schedule_once(lambda dt: root.send_text(text), 0)
                    else:
                        Clock.schedule_once(lambda dt: setattr(root, 'status', 'No speech detected.'), 0)
                @java_method('(Landroid/os/Bundle;)V')
                def onPartialResults(self, results):
                    pass
                @java_method('(ILandroid/os/Bundle;)V')
                def onEvent(self, eventType, params):
                    pass

            activity = PythonActivity.mActivity
            if not SpeechRecognizer.isRecognitionAvailable(activity):
                self.status = 'Speech recognition is not available on this phone.'
                return
            self._speech_listener = Listener()
            self._recognizer = SpeechRecognizer.createSpeechRecognizer(activity)
            self._recognizer.setRecognitionListener(self._speech_listener)
            intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, False)
            self.status = 'Starting microphone...'
            self._recognizer.startListening(intent)
        except Exception as e:
            self.status = 'Voice unavailable: ' + str(e)

class MarkApp(App):
    title = 'MARK LIV'
    def build(self):
        Window.softinput_mode = 'below_target'
        return Root()

Builder.load_string(KV)
MarkApp().run()
