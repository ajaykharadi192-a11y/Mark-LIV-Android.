[app]
title = MARK LIV
package.name = markliv
package.domain = com.markliv
source.dir = .
source.include_exts = py,png,jpg,kv,json,txt
version = 1.0
requirements = python3,kivy==2.3.1,requests,pyjnius
orientation = portrait
fullscreen = 0
android.permissions = INTERNET,RECORD_AUDIO
android.api = 35
android.minapi = 23
android.archs = arm64-v8a,armeabi-v7a
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
