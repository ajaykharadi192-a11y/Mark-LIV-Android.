# JARVIS / MARK Android Assistant

This project is the starting point for Ajju Bhai's Hindi voice assistant.

## Online APK build (without Android Code Studio)
1. Upload the contents of this ZIP to a GitHub repository (not the ZIP file itself).
2. Keep the repository private if you prefer to keep your source code private.
3. Open the repository's **Actions** tab.
4. Select **Build JARVIS APK** and tap **Run workflow** (or push to `main`/`master`).
5. When the run finishes successfully, open the run, find **Artifacts**, and download `JARVIS-debug-apk`.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`.

## Included in this starter
- Hindi speech recognition after tapping the microphone button.
- Hindi text-to-speech responses, including “हाँ Ajju Bhai, बताइए!”
- Basic commands for settings, Wi-Fi/Bluetooth/display settings, YouTube search, WhatsApp, camera, dialer, SMS draft, timer/alarm screens, time/date, battery, volume, notes, web search, weather/news/maps, translation, email and help.
- Notes saved locally on the phone.
- GitHub Actions workflow for building a debug APK online.

## Important limitations
- This is a starter build, not a finished 50-command JARVIS yet. Several commands open the relevant Android settings/app/web page rather than silently changing protected system settings.
- “Hey Jarvis” is currently recognized only while the microphone listening screen is active. Always-on wake-word listening needs a separate foreground-service design, permissions, battery testing and careful privacy handling.
- Gemini AI is not connected yet. Add AI through a secure backend; do not put a private API key directly into the Android app or public repository.
- Calls and messages open a dialer/draft for user confirmation; the app does not place calls or send messages silently.

## Planned command set (50 examples)
1. Hey Jarvis / respond to greeting
2. Ask if assistant is listening
3. Speak Hindi
4. Reply aloud
5. Stop speaking
6. Open YouTube
7. Open WhatsApp
8. Open camera
9. Open Settings
10. Open screen-lock settings
11. Turn flashlight on (currently instructions only)
12. Turn flashlight off (currently instructions only)
13. Increase volume
14. Decrease volume
15. Read battery percentage
16. Call a contact (dialer opens)
17. Find a contact (future contact permission integration)
18. Draft WhatsApp message
19. Draft SMS
20. Save a contact (future contact permission integration)
21. Ask weather via web search
22. Answer a general question (web search fallback)
23. Explain a topic (AI backend pending)
24. Translate text
25. Draft email
26. Tell current time
27. Tell today's date
28. Set timer
29. Set alarm/reminder screen
30. List saved tasks/notes
31. Search for a song
32. Search YouTube videos
33. Next song (media-session integration pending)
34. Stop music (media-session integration pending)
35. Tell a joke
36. Remember a note
37. Read saved notes
38. Make a shopping list (saved as notes)
39. Make a task list (saved as notes)
40. Show conversation history (history UI pending)
41. Search internet
42. Open news
43. Search local weather
44. Open Maps search
45. Open connectivity settings
46. Select a photo (image AI analysis pending)
47. Search with web fallback
48. Save a note
49. Open assistant/phone settings
50. Report assistant status
