package com.ajay.jarvis

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.media.AudioManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.ajay.jarvis.ui.theme.ComposeEmptyActivityTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF030811)
private val Panel = Color(0xFF091722)
private val Cyan = Color(0xFF20DDF4)
private val Muted = Color(0xFF85A6B4)
private val WhiteText = Color(0xFFE3F8FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ComposeEmptyActivityTheme { MarkApp() } }
    }
}

@Composable
private fun MarkApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("mark_settings", Context.MODE_PRIVATE) }
    var screen by remember { mutableStateOf("home") }
    var assistantName by remember { mutableStateOf(prefs.getString("assistant_name", "JARVIS") ?: "JARVIS") }
    var userName by remember { mutableStateOf(prefs.getString("user_name", "Ajju Bhai") ?: "Ajju Bhai") }
    var language by remember { mutableStateOf(prefs.getString("language", "Hindi + Hinglish") ?: "Hindi + Hinglish") }
    var geminiKey by remember { mutableStateOf(prefs.getString("gemini_key", "") ?: "") }
    var youtubeKey by remember { mutableStateOf(prefs.getString("youtube_key", "") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "Gemini 2.5 Flash") ?: "Gemini 2.5 Flash") }
    var personality by remember { mutableStateOf(prefs.getString("personality", "Assistant Mode") ?: "Assistant Mode") }
    var voice by remember { mutableStateOf(prefs.getString("voice", "Puck") ?: "Puck") }
    var youtubeEnabled by remember { mutableStateOf(prefs.getBoolean("youtube_enabled", true)) }
    var showGemini by remember { mutableStateOf(false) }
    var showYoutube by remember { mutableStateOf(false) }
    var geminiStatus by remember { mutableStateOf(if (geminiKey.isNotBlank()) "Key Configured • Not validated" else "Not configured") }
    var youtubeStatus by remember { mutableStateOf("Unverified") }
    var listening by remember { mutableStateOf(false) }
    var heardText by remember { mutableStateOf("अभी आपकी आवाज़ का इंतज़ार है।") }
    var replyText by remember { mutableStateOf("नमस्ते $userName! बोलने के लिए माइक दबाएँ।") }
    var memoryText by remember { mutableStateOf("") }
    var validationBusy by remember { mutableStateOf(false) }
    val history = remember { mutableStateListOf<String>() }
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    var ttsReady by remember { mutableStateOf(false) }
    val tts = remember {
        lateinit var engine: TextToSpeech
        engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engine.language = if (language.startsWith("English")) Locale.US else Locale("hi", "IN")
                ttsReady = true
            }
        }
        engine
    }
    val recognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(context)) SpeechRecognizer.createSpeechRecognizer(context) else null
    }
    DisposableEffect(Unit) {
        onDispose { recognizer?.destroy(); tts.stop(); tts.shutdown() }
    }

    fun speak(text: String) { if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "MARK_REPLY") }
    fun openUrl(url: String) { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun openSettings(action: String = Settings.ACTION_SETTINGS) { context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun launchSafely(intent: Intent) { intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(intent) }
    fun launchApp(packageName: String, label: String) {
        val launch = context.packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) launchSafely(launch) else openUrl("https://www.google.com/search?q=" + Uri.encode("$label app"))
    }

    val handleCommand: (String) -> Unit = { command ->
        heardText = command
        listening = false
        val words = command.lowercase(Locale.ROOT)
        val memoryPrefs = context.getSharedPreferences("mark_memory", Context.MODE_PRIVATE)
        val answer = try {
            when {
                words.contains("hey jarvis") || words.contains("हे जार्विस") || words == "jarvis" || words.contains("जार्विस") || words.contains("नमस्ते") || words.contains("hello") -> "हाँ $userName, बताइए!"
                words.contains("चुप") || words.contains("बोलना बंद") || words.contains("stop speaking") -> { tts.stop(); "ठीक है $userName, मैं चुप हो जाता हूँ।" }
                words.contains("समय") || words.contains("कितने बजे") || words.contains("time") -> "अभी समय " + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()) + " है।"
                words.contains("तारीख") || words.contains("date") -> "आज की तारीख " + SimpleDateFormat("dd MMMM yyyy", Locale("hi", "IN")).format(Date()) + " है।"
                words.contains("बैटरी") || words.contains("battery") -> {
                    val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                    "फोन की बैटरी ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} प्रतिशत है।"
                }
                words.contains("settings") || words.contains("सेटिंग") -> { openSettings(); "फोन की Settings खोल रहा हूँ।" }
                words.contains("wifi") || words.contains("वाई-फाई") -> { openSettings(Settings.ACTION_WIFI_SETTINGS); "Wi-Fi Settings खोल रहा हूँ।" }
                words.contains("bluetooth") || words.contains("ब्लूटूथ") -> { openSettings(Settings.ACTION_BLUETOOTH_SETTINGS); "Bluetooth Settings खोल रहा हूँ।" }
                words.contains("brightness") || words.contains("ब्राइटनेस") || words.contains("डिस्प्ले") -> {
                    if (Settings.System.canWrite(context)) {
                        val pct = Regex("(\\d{1,3})").find(words)?.value?.toIntOrNull()?.coerceIn(1, 100) ?: 50
                        Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, pct * 255 / 100)
                        "ब्राइटनेस $pct प्रतिशत कर दी।"
                    } else { context.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + context.packageName))); "ब्राइटनेस बदलने के लिए अगली स्क्रीन पर अनुमति दें, फिर कमांड दोहराएँ।" }
                }
                words.contains("flashlight on") || words.contains("torch on") || words.contains("टॉर्च चालू") || words.contains("फ्लैशलाइट चालू") -> {
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                        if (id != null) cm.setTorchMode(id, true)
                        "टॉर्च चालू करने का अनुरोध भेज दिया।"
                    } else "टॉर्च के लिए Settings में Camera permission दें।"
                }
                words.contains("flashlight off") || words.contains("torch off") || words.contains("टॉर्च बंद") || words.contains("फ्लैशलाइट बंद") -> {
                    val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                    val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                    if (id != null && ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) cm.setTorchMode(id, false)
                    "टॉर्च बंद करने का अनुरोध भेज दिया।"
                }
                words.contains("वॉल्यूम बढ़") || words.contains("volume up") -> { (context.getSystemService(Context.AUDIO_SERVICE) as AudioManager).adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); "वॉल्यूम बढ़ा दिया।" }
                words.contains("वॉल्यूम कम") || words.contains("volume down") -> { (context.getSystemService(Context.AUDIO_SERVICE) as AudioManager).adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); "वॉल्यूम कम कर दिया।" }
                words.contains("youtube") || words.contains("यूट्यूब") || words.contains("गाना") || words.contains("म्यूजिक") || words.contains("वीडियो") -> {
                    val query = command.replace(Regex("(?i)youtube|यूट्यूब|पर|खोलो|चलाओ|खोजो|सर्च करो|गाना|म्यूजिक|वीडियो"), "").trim()
                    openUrl(if (query.isBlank()) "https://www.youtube.com" else "https://www.youtube.com/results?search_query=" + Uri.encode(query))
                    "YouTube पर खोज रहा हूँ।"
                }
                words.contains("whatsapp") || words.contains("व्हाट्सएप") -> { launchApp("com.whatsapp", "WhatsApp"); "WhatsApp खोल रहा हूँ। मैसेज भेजने से पहले आप जाँच लें।" }
                words.contains("instagram") -> { launchApp("com.instagram.android", "Instagram"); "Instagram खोल रहा हूँ।" }
                words.contains("spotify") -> { launchApp("com.spotify.music", "Spotify"); "Spotify खोल रहा हूँ।" }
                words.contains("कैमरा") || words.contains("camera") -> { launchSafely(Intent("android.media.action.IMAGE_CAPTURE")); "कैमरा खोल रहा हूँ।" }
                words.contains("कॉल") || words.contains("call") || words.contains("फोन लगाओ") -> { launchSafely(Intent(Intent.ACTION_DIAL)); "डायलर खोल रहा हूँ। नंबर जाँचकर कॉल करें।" }
                words.contains("मैसेज") || words.contains("message") || words.contains("sms") -> { launchSafely(Intent(Intent.ACTION_VIEW, Uri.parse("smsto:")).putExtra("sms_body", command)); "मैसेज ड्राफ्ट खोल रहा हूँ। भेजने से पहले जाँच लें।" }
                words.contains("मौसम") || words.contains("weather") -> { openUrl("https://www.google.com/search?q=" + Uri.encode("आज का मौसम $command")); "मौसम खोज रहा हूँ।" }
                words.contains("खबर") || words.contains("news") -> { openUrl("https://news.google.com/"); "ताज़ा खबरें खोल रहा हूँ।" }
                words.contains("मैप") || words.contains("रास्ता") || words.contains("maps") || words.contains("दिशा") -> { openUrl("https://www.google.com/maps/search/" + Uri.encode(command)); "Maps खोल रहा हूँ।" }
                words.contains("टाइमर") || words.contains("timer") -> {
                    val minutes = Regex("(\\d+)").find(command)?.value?.toIntOrNull() ?: 1
                    launchSafely(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, (minutes * 60).coerceAtMost(86400)).putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS Timer").putExtra(AlarmClock.EXTRA_SKIP_UI, false))
                    "$minutes मिनट का टाइमर सेट करने की स्क्रीन खोल रहा हूँ।"
                }
                words.contains("अलार्म") || words.contains("alarm") || words.contains("remind") || words.contains("याद दिला") -> { launchSafely(Intent(AlarmClock.ACTION_SET_ALARM)); "अलार्म सेट करने की स्क्रीन खोल रहा हूँ।" }
                words.contains("नोट्स दिख") || words.contains("मेरी यादें") || words.contains("saved notes") || words.contains("read notes") -> { val notes = memoryPrefs.getString("notes", "")?.trim().orEmpty(); if (notes.isBlank()) "अभी कोई नोट सेव नहीं है।" else "आपके नोट्स: $notes" }
                words.contains("forget") || words.contains("भूल जाओ") || words.contains("नोट मिटा") -> { memoryPrefs.edit().remove("notes").apply(); "सेव किए हुए नोट मिटा दिए।" }
                words.contains("नोट") || words.contains("याद रख") || words.contains("remember") || words.contains("save this") || words.contains("shopping list") || words.contains("खरीदारी सूची") -> {
                    val note = command.replace(Regex("(?i)jarvis|hey|याद रखो|याद रखना|नोट बनाओ|नोट|remember|save this"), "").trim().ifBlank { command }
                    val old = memoryPrefs.getString("notes", "") ?: ""
                    memoryPrefs.edit().putString("notes", (old + "\n• " + note).trim()).apply()
                    "ठीक है $userName, मैंने नोट सेव कर लिया।"
                }
                words.contains("ईमेल") || words.contains("email") -> { launchSafely(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))); "ईमेल ऐप खोल रहा हूँ।" }
                words.contains("अनुवाद") || words.contains("translate") -> { openUrl("https://translate.google.com/?sl=auto&tl=hi&text=" + Uri.encode(command)); "अनुवाद खोल रहा हूँ।" }
                words.contains("फोटो") || words.contains("तस्वीर") || words.contains("vision") || words.contains("image") -> { launchSafely(Intent(Intent.ACTION_GET_CONTENT).setType("image/*")); "तस्वीर चुनने की स्क्रीन खोल रहा हूँ। AI विश्लेषण के लिए Gemini कनेक्शन अभी बाकी है।" }
                words.contains("history") || words.contains("इतिहास") -> { screen = "history"; "आपकी बातचीत का इतिहास खोल रहा हूँ।" }
                words.contains("जोक") || words.contains("चुटकुला") || words.contains("joke") -> "कंप्यूटर डॉक्टर के पास क्यों गया? क्योंकि उसे वायरस हो गया था!"
                words.contains("lock") || words.contains("लॉक") -> { openSettings(Settings.ACTION_SECURITY_SETTINGS); "स्क्रीन लॉक की Settings खोल रहा हूँ। सुरक्षा लॉक को बायपास नहीं किया जा सकता।" }
                words.contains("status") || words.contains("स्टेटस") -> "${assistantName} चालू है। माइक दबाकर बोलें। हमेशा चालू Hey Jarvis अभी समर्थित नहीं है।"
                words.contains("sleep") || words.contains("सो जाओ") -> { screen = "sleep"; "ठीक है, मैं स्लीप स्क्रीन पर जा रहा हूँ।" }
                words.contains("help") || words.contains("कमांड") || words.contains("commands") -> "समय, तारीख, बैटरी, YouTube, WhatsApp, Instagram, Spotify, कैमरा, सेटिंग्स, टॉर्च चालू/बंद, ब्राइटनेस 50 प्रतिशत, वॉल्यूम बढ़ाओ, कॉल, मैसेज, मौसम, खबर, Maps, टाइमर, अलार्म, नोट याद रखो, नोट्स दिखाओ, भूल जाओ, फोटो, इतिहास या चुटकुला कहें।"
                else -> { openUrl("https://www.google.com/search?q=" + Uri.encode(command)); "इस कमांड के लिए वेब खोज खोल रहा हूँ। सामान्य Gemini बातचीत के लिए API कनेक्शन और सुरक्षित backend जोड़ना बाकी है।" }
            }
        } catch (_: Exception) { "यह काम पूरा नहीं हो पाया। अनुमति या ऐप उपलब्धता जाँचें।" }
        replyText = answer
        history.add("आप: $command\n$assistantName: $answer")
        speak(answer)
    }

    val startListening: () -> Unit = {
        if (recognizer == null) replyText = "इस फोन पर Speech Recognition उपलब्ध नहीं है।"
        else try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (language.startsWith("English")) "en-IN" else "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "$userName, बोलिए…")
            }
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { listening = true; replyText = "सुन रहा हूँ, $userName…" }
                override fun onBeginningOfSpeech() { listening = true }
                override fun onResults(results: Bundle?) { val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull(); if (spoken.isNullOrBlank()) { listening = false; replyText = "आवाज़ समझ नहीं आई। फिर बोलिए।" } else handleCommand(spoken) }
                override fun onError(error: Int) { listening = false; replyText = "आवाज़ नहीं समझ पाया। दोबारा माइक दबाएँ।" }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { listening = false }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            recognizer.startListening(intent)
        } catch (_: Exception) { listening = false; replyText = "माइक शुरू नहीं हो पाया। अनुमति जाँचें।" }
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) startListening() else replyText = "आवाज़ सुनने के लिए Microphone permission चाहिए।" }
    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> replyText = if (granted) "Camera permission मिल गई। अब टॉर्च कमांड दोहराएँ।" else "टॉर्च के लिए Camera permission चाहिए।" }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel, onPrimary = Bg, onSurface = WhiteText)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            when (screen) {
                "settings" -> SettingsPage(
                    assistantName, { assistantName = it }, userName, { userName = it }, language, { language = it },
                    geminiKey, { geminiKey = it; geminiStatus = if (it.isBlank()) "Not configured" else "Key entered • Not validated" },
                    youtubeKey, { youtubeKey = it; youtubeStatus = "Unverified" }, model, { model = it }, personality, { personality = it }, voice, { voice = it },
                    youtubeEnabled, { youtubeEnabled = it }, showGemini, { showGemini = it }, showYoutube, { showYoutube = it }, geminiStatus, youtubeStatus, validationBusy,
                    onBack = { screen = "home" }, onSave = {
                        prefs.edit().putString("assistant_name", assistantName).putString("user_name", userName).putString("language", language).putString("gemini_key", geminiKey).putString("youtube_key", youtubeKey).putString("model", model).putString("personality", personality).putString("voice", voice).putBoolean("youtube_enabled", youtubeEnabled).apply()
                        replyText = "सेटिंग्स सेव हो गईं।"; screen = "home"
                    }, onPasteGemini = { geminiKey = clipboard.getText()?.text.orEmpty(); geminiStatus = "Key entered • Not validated" },
                    onPasteYoutube = { youtubeKey = clipboard.getText()?.text.orEmpty(); youtubeStatus = "Unverified" },
                    onValidateGemini = {
                        if (geminiKey.isBlank()) geminiStatus = "पहले API key डालें" else scope.launch {
                            validationBusy = true; geminiStatus = "Validating…"
                            geminiStatus = withContext(Dispatchers.IO) { validateUrl("https://generativelanguage.googleapis.com/v1beta/models?key=" + Uri.encode(geminiKey)) }
                            validationBusy = false
                        }
                    }, onValidateYoutube = {
                        if (youtubeKey.isBlank()) youtubeStatus = "पहले API key डालें" else scope.launch {
                            validationBusy = true; youtubeStatus = "Validating…"
                            youtubeStatus = withContext(Dispatchers.IO) { validateUrl("https://www.googleapis.com/youtube/v3/videos?part=id&id=dQw4w9WgXcQ&key=" + Uri.encode(youtubeKey)) }
                            validationBusy = false
                        }
                    }, onManagePermissions = { context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + context.packageName))) },
                    onAllowMic = { micPermission.launch(Manifest.permission.RECORD_AUDIO) }, onAllowCamera = { cameraPermission.launch(Manifest.permission.CAMERA) }, onViewMemories = { memoryText = context.getSharedPreferences("mark_memory", Context.MODE_PRIVATE).getString("notes", "") ?: ""; screen = "memories" },
                    onClearMemories = { context.getSharedPreferences("mark_memory", Context.MODE_PRIVATE).edit().clear().apply(); memoryText = ""; replyText = "सारी सेव की गई यादें साफ कर दी गईं।" }
                )
                "history" -> SimplePage("CONVERSATION HISTORY", { screen = "home" }) {
                    if (history.isEmpty()) Text("अभी इस session में कोई बातचीत नहीं है।", color = Muted)
                    history.reversed().forEach { Text(it, color = WhiteText, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).background(Panel, RoundedCornerShape(12.dp)).padding(12.dp)) }
                    Button(onClick = { history.clear() }) { Text("CLEAR HISTORY") }
                }
                "memories" -> SimplePage("MEMORY CORE", { screen = "settings" }) { Text(if (memoryText.isBlank()) "कोई सेव नोट नहीं है।" else memoryText, color = WhiteText) }
                "sleep" -> SimplePage("SLEEP MODE", { screen = "home" }) { Text("स्लीप स्क्रीन। वापस आने के लिए Back दबाएँ।", color = Muted) }
                else -> Dashboard(assistantName, userName, listening, heardText, replyText, onSettings = { screen = "settings" }, onMic = {
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startListening() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                }, onVision = { launchSafely(Intent(Intent.ACTION_GET_CONTENT).setType("image/*")); replyText = "तस्वीर चुनें। AI image analysis अभी API से जुड़ा नहीं है।" }, onHistory = { screen = "history" }, onSleep = { screen = "sleep" }, onPermission = { cameraPermission.launch(Manifest.permission.CAMERA) })
            }
        }
    }
}

private fun validateUrl(url: String): String {
    var connection: HttpURLConnection? = null
    return try {
        connection = (URL(url).openConnection() as HttpURLConnection).apply { requestMethod = "GET"; connectTimeout = 10000; readTimeout = 10000 }
        when (connection.responseCode) {
            in 200..299 -> "Valid • API responded successfully"
            403 -> "403 • API/key/quota restriction; check Google Cloud settings"
            400, 401 -> "Invalid key or request (${connection.responseCode})"
            else -> "HTTP ${connection.responseCode} • Check key and API settings"
        }
    } catch (_: Exception) { "Network error • Check internet and retry" } finally { connection?.disconnect() }
}

@Composable
private fun Dashboard(name: String, userName: String, listening: Boolean, heard: String, reply: String, onSettings: () -> Unit, onMic: () -> Unit, onVision: () -> Unit, onHistory: () -> Unit, onSleep: () -> Unit, onPermission: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "orb")
    val pulse by transition.animateFloat(initialValue = 0.96f, targetValue = 1.04f, animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "pulse")
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF061724), Bg, Color.Black))).padding(18.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(name, color = WhiteText, fontSize = 24.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                Text(if (listening) "● LISTENING" else "● CALM — SYSTEM ONLINE", color = Cyan, fontSize = 11.sp)
            }
            Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()), color = WhiteText, fontSize = 20.sp)
            Spacer(Modifier.width(12.dp))
            Button(onClick = onSettings, colors = ButtonDefaults.buttonColors(containerColor = Panel)) { Text("⚙", fontSize = 20.sp) }
        }
        Spacer(Modifier.height(22.dp))
        Box(Modifier.fillMaxWidth().weight(0.9f), contentAlignment = Alignment.Center) {
            Box(Modifier.size(230.dp).scale(pulse).border(1.dp, Cyan.copy(alpha = 0.7f), CircleShape).padding(18.dp).border(1.dp, Color(0xFF1A779A), CircleShape).padding(18.dp).background(Brush.radialGradient(listOf(Color(0xFF0D5E78), Color(0xFF07172B), Bg)), CircleShape), contentAlignment = Alignment.Center) {
                Text(if (listening) "◉" else "✣", color = Cyan, fontSize = 62.sp)
            }
        }
        Text("CONVERSATION", color = Muted, fontSize = 12.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(8.dp))
        Column(Modifier.fillMaxWidth().weight(1.1f).background(Panel, RoundedCornerShape(20.dp)).border(1.dp, Color(0xFF164859), RoundedCornerShape(20.dp)).padding(14.dp)) {
            Text("You  •  ${SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())}", color = Muted, fontSize = 11.sp)
            Text(heard, color = WhiteText, modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 14.dp).background(Color(0xFF0C3542), RoundedCornerShape(12.dp)).padding(12.dp))
            Text(name, color = Cyan, fontSize = 11.sp)
            Text(reply, color = WhiteText, modifier = Modifier.padding(top = 5.dp))
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = onSleep, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF20232E)), contentPadding = PaddingValues(horizontal = 6.dp, vertical = 12.dp)) { Text("SLEEP", fontSize = 10.sp) }
            Button(onClick = onVision, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF123340)), contentPadding = PaddingValues(horizontal = 6.dp, vertical = 12.dp)) { Text("VISION", fontSize = 10.sp) }
            Button(onClick = onMic, modifier = Modifier.size(66.dp), shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = Cyan)) { Text("🎙", fontSize = 24.sp, color = Bg) }
            Button(onClick = onHistory, modifier = Modifier.weight(1.2f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF20232E)), contentPadding = PaddingValues(horizontal = 6.dp, vertical = 12.dp)) { Text("HISTORY", fontSize = 10.sp) }
        }
        Spacer(Modifier.height(6.dp))
        Text("Wake phrase ‘Hey Jarvis’ requires the mic button in this version. Background listening is not active.", color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun SettingsPage(
    assistantName: String, onAssistantName: (String) -> Unit, userName: String, onUserName: (String) -> Unit, language: String, onLanguage: (String) -> Unit,
    geminiKey: String, onGeminiKey: (String) -> Unit, youtubeKey: String, onYoutubeKey: (String) -> Unit, model: String, onModel: (String) -> Unit, personality: String, onPersonality: (String) -> Unit, voice: String, onVoice: (String) -> Unit,
    youtubeEnabled: Boolean, onYoutubeEnabled: (Boolean) -> Unit, showGemini: Boolean, onShowGemini: (Boolean) -> Unit, showYoutube: Boolean, onShowYoutube: (Boolean) -> Unit, geminiStatus: String, youtubeStatus: String, busy: Boolean,
    onBack: () -> Unit, onSave: () -> Unit, onPasteGemini: () -> Unit, onPasteYoutube: () -> Unit, onValidateGemini: () -> Unit, onValidateYoutube: () -> Unit, onManagePermissions: () -> Unit, onAllowMic: () -> Unit, onAllowCamera: () -> Unit, onViewMemories: () -> Unit, onClearMemories: () -> Unit
) {
    val context = LocalContext.current
    LazyColumn(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF061724), Bg, Color.Black))).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                OutlinedButton(onClick = onBack) { Text("‹ BACK") }
                Text("Settings", color = WhiteText, fontSize = 25.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                TextButton(onClick = onSave) { Text("SAVE", color = Cyan, fontWeight = FontWeight.Bold, letterSpacing = 2.sp) }
            }
        }
        item { SectionTitle("Assistant Profile", "◉"); PanelCard {
            LabeledField("ASSISTANT NAME", assistantName, onAssistantName, "MARK or JARVIS")
            LabeledField("USER NAME", userName, onUserName, "Ajju Bhai")
            ChoiceRow("PREFERRED LANGUAGE", listOf("Hindi + Hinglish", "Hindi", "English"), language, onLanguage)
            ChoiceRow("PERSONALITY", listOf("Friendly", "Helpful", "Assistant Mode", "Custom"), personality, onPersonality)
            if (personality == "Custom") Text("Custom personality: calm, helpful, concise. Custom text editor can be added later.", color = Muted, fontSize = 12.sp)
        } }
        item { SectionTitle("API Key", "⚿"); PanelCard {
            LabeledField("GEMINI API KEY", geminiKey, onGeminiKey, "Paste Gemini API key", !showGemini)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onPasteGemini) { Text("Paste from clipboard", color = Cyan) }
                TextButton(onClick = { onShowGemini(!showGemini) }) { Text(if (showGemini) "Hide key" else "Show key", color = Muted) }
            }
            ChoiceRow("AI MODEL", listOf("Gemini 2.5 Flash", "Gemini 2.5 Pro", "Gemini 2.0 Flash", "Gemini 3.0 Live (Voice Agent)"), model, onModel)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = onValidateGemini, enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF103A47))) { Text("VALIDATE KEY") }
                Spacer(Modifier.width(10.dp)); Text(geminiStatus, color = if (geminiStatus.startsWith("Valid")) Color(0xFF42E7A5) else Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
            }
            Text("Production note: API keys stored on the phone are not suitable for public distribution. Use a secure backend for a published app.", color = Muted, fontSize = 11.sp)
        } }
        item { SectionTitle("Voice", "♬"); PanelCard {
            Text("Select voice (available only if your configured service supports it)", color = Muted, fontSize = 12.sp)
            val voices = listOf("Puck", "Charon", "Kore", "Fenrir", "Aoede", "Leda", "Orus", "Zephyr")
            voices.chunked(4).forEach { group -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) { group.forEach { v -> FilterChip(selected = voice == v, onClick = { onVoice(v) }, label = { Text(v, fontSize = 11.sp) }) } } }
            Text("Android Text-to-Speech uses the phone's installed voice. These names are saved as a preference and do not switch Android voices by themselves.", color = Muted, fontSize = 11.sp)
        } }
        item { SectionTitle("Permissions", "▣"); PanelCard {
            val micGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            val cameraGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
            Text("${if (micGranted) "✓" else "○"} Microphone: ${if (micGranted) "Granted" else "Missing"}", color = if (micGranted) Color(0xFF42E7A5) else WhiteText)
            Text("${if (cameraGranted) "✓" else "○"} Camera / flashlight: ${if (cameraGranted) "Granted" else "Missing"}", color = if (cameraGranted) Color(0xFF42E7A5) else WhiteText)
            Text("Internet: declared in app manifest; network access still depends on connectivity.", color = Muted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Button(onClick = onAllowMic, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)) { Text("ALLOW MIC", fontSize = 11.sp) }; Button(onClick = onAllowCamera, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)) { Text("ALLOW CAMERA", fontSize = 11.sp) } }; OutlinedButton(onClick = onManagePermissions, modifier = Modifier.fillMaxWidth()) { Text("MANAGE PERMISSIONS") }
            Text("Screen unlock cannot be bypassed. Use Android PIN, pattern, biometric or system security screen.", color = Muted, fontSize = 11.sp)
        } }
        item { SectionTitle("Memory Core", "▤"); PanelCard {
            Text("Short-term conversation buffer + local notes and preferences", color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick = onClearMemories, modifier = Modifier.weight(1f)) { Text("CLEAR", color = Color(0xFFFF628A)) }; Button(onClick = onViewMemories, modifier = Modifier.weight(1f)) { Text("VIEW MEMORIES") } }
            Text("Memory is stored locally on this device. Avoid saving sensitive information.", color = Muted, fontSize = 11.sp)
        } }
        item { SectionTitle("YouTube Automation", "▷"); PanelCard {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) { Text("Enable YouTube Automation", color = WhiteText); Switch(checked = youtubeEnabled, onCheckedChange = onYoutubeEnabled) }
            Text("YouTube Data API v3 key for searching songs, videos and playlists.", color = Muted, fontSize = 12.sp)
            LabeledField("YOUTUBE API KEY", youtubeKey, onYoutubeKey, "Paste YouTube API key", !showYoutube)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onPasteYoutube) { Text("Paste from clipboard", color = Cyan) }
                TextButton(onClick = { onShowYoutube(!showYoutube) }) { Text(if (showYoutube) "Hide key" else "Show key", color = Muted) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) { Button(onClick = onValidateYoutube, enabled = !busy) { Text("VALIDATE KEY") }; Spacer(Modifier.width(10.dp)); Text("Status: $youtubeStatus", color = if (youtubeStatus.startsWith("Valid")) Color(0xFF42E7A5) else Muted, fontSize = 11.sp, modifier = Modifier.weight(1f)) }
        } }
        item { SectionTitle("Mobile Control", "▯"); PanelCard {
            listOf("‘Turn flashlight on / off’", "‘Set brightness to 50%’ / ‘Increase brightness’", "‘Volume up / down’", "‘Open Instagram’, ‘Open WhatsApp’, ‘Open Spotify’", "‘Send WhatsApp to Rahul saying I will be late’ — draft/review only", "‘Call Rahul’ — opens dialer; no silent calling", "‘Remember my gym starts at 6 PM’, ‘Forget routine’").forEach { Text("▪  $it", color = WhiteText, modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp)) }
            Divider(color = Color(0xFF1B3A45), modifier = Modifier.padding(vertical = 8.dp))
            Text("WhatsApp confirmation policy: Active", color = Color(0xFF42E7A5), fontWeight = FontWeight.Bold)
            Text("This build does not silently send messages or initiate calls. Some controls require Android permission or system confirmation.", color = Muted, fontSize = 11.sp)
        } }
        item { Text("Note: Gemini chat, image understanding, true wake-word listening, background routines, and direct YouTube API search need additional service/backend work. Settings and command options shown here do not imply those unfinished features are active.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 24.dp)) }
    }
}

@Composable
private fun SectionTitle(title: String, symbol: String) { Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) { Box(Modifier.size(42.dp).background(Color(0xFF0B2534), RoundedCornerShape(12.dp)).border(1.dp, Color(0xFF1D5264), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Text(symbol, color = Cyan, fontSize = 20.sp) }; Spacer(Modifier.width(12.dp)); Text(title, color = WhiteText, fontSize = 19.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp) } }

@Composable
private fun PanelCard(content: @Composable ColumnScope.() -> Unit) { Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content) } }

@Composable
private fun LabeledField(label: String, value: String, onValue: (String) -> Unit, placeholder: String, hidden: Boolean = false) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(label, color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
        OutlinedTextField(value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth(), placeholder = { Text(placeholder, color = Muted) }, singleLine = true, visualTransformation = if (hidden) PasswordVisualTransformation() else VisualTransformation.None, keyboardOptions = KeyboardOptions(keyboardType = if (label.contains("KEY")) KeyboardType.Password else KeyboardType.Text), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Color(0xFF21414D), focusedTextColor = WhiteText, unfocusedTextColor = WhiteText, cursorColor = Cyan))
    }
}

@Composable
private fun ChoiceRow(label: String, choices: List<String>, selected: String, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Column {
        Text(label, color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selected, color = WhiteText, modifier = Modifier.weight(1f)); Text("⌄", color = Cyan) }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { choices.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onSelect(option); expanded = false }) } }
        }
    }
}

@Composable
private fun SimplePage(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).padding(18.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { OutlinedButton(onClick = onBack) { Text("‹ BACK") }; Spacer(Modifier.width(14.dp)); Text(title, color = WhiteText, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(16.dp)); Column(Modifier.fillMaxSize(), content = content)
    }
}
