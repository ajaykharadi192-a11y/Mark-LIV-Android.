# JARVIS / MARK Android project

This is a Kotlin + Jetpack Compose Android project for the MARK/JARVIS assistant UI and starter command system.

## Build an APK with GitHub Actions

1. Extract this archive. The `JARVIS` folder contains `gradlew`, `settings.gradle.kts`, `app/`, and `.github/`.
2. Upload the **contents of the JARVIS folder** to the root of your GitHub repository, or use your repository's existing ZIP-unpack workflow with this archive.
3. In GitHub, open **Actions → Build JARVIS APK → Run workflow** (or push a commit).
4. Open the completed run and download the `JARVIS-debug-apk` artifact.

If your repository uses a workflow that extracts `JARVIS-50-commands-*.zip`, remove older matching ZIPs before uploading this new ZIP so the workflow doesn't accidentally unpack an old archive.

## Included UI

- Dark cyan-neon dashboard with animated orb, conversation panel, status, settings, microphone, vision picker, sleep screen, and history.
- Settings screen with assistant/user names, language, personality, Gemini API key, model choice, voice preference chips, YouTube automation toggle and API key, validate buttons, permission status/actions, memory controls, and mobile-control guide.
- Local note memory and session conversation history.
- Voice input through Android SpeechRecognizer and spoken responses through Android TextToSpeech.
- Starter voice commands for greeting, time/date/battery, settings, Wi-Fi/Bluetooth, brightness permission flow, flashlight with camera permission, volume, YouTube search, app launching, dialer, SMS draft, weather/news/maps/web search, timer/alarm, notes, translation, image picker, history, jokes, and status.

## Important limitations

This is a starter implementation, not a finished always-on AI assistant. “Hey Jarvis” is not a background wake-word service; tap the microphone to speak. Gemini and YouTube key validation make a network request, but Gemini chat responses, image understanding, direct YouTube Data API search/results, live voice models, persistent reminders, and true WhatsApp contact-specific automation are not fully wired. Model and voice selections are saved preferences; they do not activate a cloud model or switch Android's installed TTS voice by themselves. The app opens the dialer or message draft and does not silently call or send messages. Android may require system permissions and user confirmation for brightness, flashlight, app access, or device security.

API keys are stored in local app preferences for this prototype. Do not publish or share a build containing a real personal API key. For production, route API requests through a secure backend and protect secrets there.

The source ZIP is not itself an APK. A successful GitHub Actions run is needed to create the APK artifact. Build status has not been independently verified in this environment.
